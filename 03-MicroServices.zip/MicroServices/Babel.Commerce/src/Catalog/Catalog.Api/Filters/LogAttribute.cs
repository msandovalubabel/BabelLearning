﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Catalog.Api.Filters
{
    public class LogAttribute:ActionFilterAttribute
    {
        private static readonly ILogger logger = LoggerFactory.Create(x=>x.AddConsole()).CreateLogger("LogAtribute");
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            logger.LogInformation($"Llamada a Metodo {context.ActionDescriptor.DisplayName}");
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
            logger.LogInformation($"Metodo ejecutado {context.ActionDescriptor.DisplayName}");
        }
    }
}
