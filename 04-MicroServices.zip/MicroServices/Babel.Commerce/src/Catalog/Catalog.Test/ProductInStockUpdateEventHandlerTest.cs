using Catalog.Service.EventHandlers;
using Catalog.Service.EventHandlers.Commands;
using Catalog.Service.EventHandlers.Exceptions;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Catalog.Test
{
    [TestClass]
    public class ProductInStockUpdateEventHandlerTest
    {
        private ILogger<ProductInStockUpdateEventHandler> GetLogger
        {
            get
            {
                return new Mock<ILogger<ProductInStockUpdateEventHandler>>().Object;
            }
        }

        [TestMethod]
        public void SustraerStockConExistencias()
        {
            var context = Config.ApplicationDbContextInMemory.Get();
            var productId = 1;
            var productInStockId = 1;
            context.Stocks.Add(new Domain.ProductInStock
            {
                ProductId = productId,
                ProductInStockId = productInStockId,
                Stock = 1
            });

            context.SaveChanges();

            var handler = new ProductInStockUpdateEventHandler(context, GetLogger);
            handler.Handle(new ProductInStockUpdateCommand
            {
                Items = new List<ProductStockUpdateItem>(){
                    new ProductStockUpdateItem{
                        ProductId=productId,
                        Stock=1,
                        Action=Common.Enums.ProductInStockAction.Substract
                    }
                }
            }, new System.Threading.CancellationToken()
                ).Wait();

        }

        [TestMethod]
        [ExpectedException(typeof(ProductInStockUpdateStockCommandException))]
        public void SustraerStockSinExistencias()
        {
            var context = Config.ApplicationDbContextInMemory.Get();
            var productId = 2;
            var productInStockId = 2;
            context.Stocks.Add(new Domain.ProductInStock
            {
                ProductId = productId,
                ProductInStockId = productInStockId,
                Stock = 1
            });

            context.SaveChanges();

            var handler = new ProductInStockUpdateEventHandler(context, GetLogger);

            try
            {
                handler.Handle(new ProductInStockUpdateCommand
                {
                    Items = new List<ProductStockUpdateItem>(){
                    new ProductStockUpdateItem{
                        ProductId=productId,
                        Stock=2,
                        Action=Common.Enums.ProductInStockAction.Substract
                    }
                }
                }, new System.Threading.CancellationToken()
                ).Wait();
            }
            catch (AggregateException ex)
            {
                var exception = ex.GetBaseException();
                if (exception is ProductInStockUpdateStockCommandException)
                {
                    throw new ProductInStockUpdateStockCommandException(exception?.InnerException?.Message);

                }
            }
            

        }

        [TestMethod]
        public void AgregarStockConExistencias()
        {
            var context = Config.ApplicationDbContextInMemory.Get();
            var productId = 5;
            var productInStockId = 5;
            context.Stocks.Add(new Domain.ProductInStock
            {
                ProductId = productId,
                ProductInStockId = productInStockId,
                Stock = 1
            });

            context.SaveChanges();

            var handler = new ProductInStockUpdateEventHandler(context, GetLogger);
            handler.Handle(new ProductInStockUpdateCommand
            {
                Items = new List<ProductStockUpdateItem>(){
                    new ProductStockUpdateItem{
                        ProductId=productId,
                        Stock=2,
                        Action=Common.Enums.ProductInStockAction.Add
                    }
                }
            }, new System.Threading.CancellationToken()
                ).Wait();

            var stockdb = context.Stocks.Single(x=>x.ProductId==productId).Stock;

            Assert.AreEqual(stockdb,3);
        }

        [TestMethod]
        public void AgregarStockAProductoNoExistente()
        {
            var context = Config.ApplicationDbContextInMemory.Get();
            var productId = 4;            

            context.SaveChanges();

            var handler = new ProductInStockUpdateEventHandler(context, GetLogger);
            handler.Handle(new ProductInStockUpdateCommand
            {
                Items = new List<ProductStockUpdateItem>(){
                    new ProductStockUpdateItem{
                        ProductId=productId,
                        Stock=2,
                        Action=Common.Enums.ProductInStockAction.Add
                    }
                }
            }, new System.Threading.CancellationToken()
                ).Wait();

            var stockdb = context.Stocks.Single(x => x.ProductId == productId).Stock;

            Assert.AreEqual(stockdb, 2);
        }
    }
}
