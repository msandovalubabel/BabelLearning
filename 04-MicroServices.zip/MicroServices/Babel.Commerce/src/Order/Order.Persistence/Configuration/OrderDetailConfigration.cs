﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Order.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Persistence.Database.Configuration
{
    public class OrderDetailConfigration
    {
        public OrderDetailConfigration(EntityTypeBuilder<OrderDetail> entityBuilder)
        {
            entityBuilder.HasKey(y=>y.OrderDetailId);
        }
    }
}
