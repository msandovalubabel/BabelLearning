﻿using System;

namespace Order.Services.Proxies
{
    public class ApiUrls
    {
        public string CatalogUrl { get; set; }

    }
}
