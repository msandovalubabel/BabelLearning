﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Servicios.api.libreria.Core.Entities
{
    public class Autor
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        
        [BsonElement("nombre")]
        public string Nombre { get; set; }
        
        [BsonElement("apellido")]
        public string Apellido { get; set; }

        [BsonElement("gradoacademico")]
        public string GradoAcademico { get; set; }
    }
}
