﻿namespace Api.Gateway.Proxy
{
    public class ApiUrls
    {
        public string IdentityUrl { get; set; }
        public string CatalogUrl { get; set; }
        public string CustomerUrl { get; set; }
        public string OrderUrl { get; set; }
    }
}
