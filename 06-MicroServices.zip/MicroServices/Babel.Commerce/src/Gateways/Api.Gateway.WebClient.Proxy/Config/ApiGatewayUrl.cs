﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Gateway.WebClient.Proxy.Config
{
    public class ApiGatewayUrl
    {
        public ApiGatewayUrl(string url)
        {
            Value = url;
        }

        public readonly string Value;
    }
}
