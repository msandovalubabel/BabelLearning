﻿using Catalog.Service.Queries.DTO;
using Service.Common.Collection;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Catalog.Service.Queries
{
    public interface IProductQueryService
    {
        Task<ProductDto> GetAsync(int id);
        Task<DataCollection<ProductDto>> GetAllAsync(int page,int take, IEnumerable<int> products=null);
    }
}
