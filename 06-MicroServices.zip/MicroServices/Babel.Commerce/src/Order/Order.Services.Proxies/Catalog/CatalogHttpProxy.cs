﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Order.Services.Proxies.Catalog.Command;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Order.Services.Proxies.Catalog
{
    public class CatalogHttpProxy : ICatalogProxy
    {
        private readonly HttpClient _httpClient;
        private readonly ApiUrls _apiUrls;
        public CatalogHttpProxy(HttpClient httpClient, IOptions<ApiUrls> apiUrls, IHttpContextAccessor httpContextAccessor)
        {
            httpClient.AddBearerToken(httpContextAccessor);
            _httpClient = httpClient;
            _apiUrls = apiUrls.Value;
        }
        public async Task UpdateStockAsync(ProductInStockUpdateCommand command)
        {
            var content = new StringContent(
                    JsonSerializer.Serialize(command),
                    Encoding.UTF8,
                    "application/json"
                );

            var request = await _httpClient.PutAsync(_apiUrls.CatalogUrl + "stocks", content);
            request.EnsureSuccessStatusCode();
        }

        
    }
}
