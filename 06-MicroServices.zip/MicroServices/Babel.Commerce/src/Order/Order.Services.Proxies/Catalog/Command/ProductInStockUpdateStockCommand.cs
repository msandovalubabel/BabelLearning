﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Services.Proxies.Catalog.Command
{
    public class ProductInStockUpdateCommand 
    {
        public IEnumerable<ProductStockUpdateItem> Items { get; set; } = new List<ProductStockUpdateItem>();
    }

    public class ProductStockUpdateItem
    {
        public int ProductId { get; set; }
        public int Stock { get; set; }
        public ProductInStockAction Action { get; set; }
    }
    public enum ProductInStockAction
    {
        Add,
        Substract
    }
}
