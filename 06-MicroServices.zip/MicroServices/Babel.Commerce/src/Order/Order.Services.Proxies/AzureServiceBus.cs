﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Services.Proxies
{
    public class AzureServiceBus
    {
        public string ConnectionString { get; set; }
        public string QueueName { get; set; }
    }
}
