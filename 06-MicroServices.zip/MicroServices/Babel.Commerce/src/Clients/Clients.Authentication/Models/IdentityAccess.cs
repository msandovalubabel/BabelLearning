﻿namespace Clients.Authentication.Models
{
    public class IdentityAccess
    {
        public string AccessToken { get; set; }
    }
}
