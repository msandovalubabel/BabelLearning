﻿using Catalog.Persistence.Database;
using Catalog.Service.Queries.DTO;
using Microsoft.EntityFrameworkCore;
using Service.Common.Collection;
using Service.Common.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using Service.Common.Paging;

namespace Catalog.Service.Queries
{
    public class ProductQueryService : IProductQueryService
    {
        private readonly ApplicationDbContext _contex;
        public ProductQueryService(ApplicationDbContext contex)
        {
            _contex = contex;
        }
        public async Task<DataCollection<ProductDto>> GetAllAsync(int page, int take, IEnumerable<int> products = null)
        {
            var callection = await _contex.Products.Where(
                x => products == null || products.Contains(x.ProductId)).OrderByDescending(x => x.ProductId)
                .GetPagedAsync(page,take);
            return callection.MapTo<DataCollection<ProductDto>>();
        }

        public async Task<ProductDto> GetAsync(int id)
        {
            return (await _contex.Products.SingleAsync(x=>x.ProductId==id)).MapTo<ProductDto>();
        }
    }
}
