﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Catalog.Service.EventHandlers.Commands
{
    class ProductInStockUpdateStockCommand:INotification
    {
        public IEnumerable<ProductStockUpdateItem> Items { get; set; } = new List<ProductStockUpdateItem>();
    }

    public class ProductStockUpdateItem
    {
        public int ProductId { get; set; }
        public int Stock { get; set; }
        //public int ProductInStockAction Action { get; set; }
    }
}
