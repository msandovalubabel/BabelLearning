﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Gateway.WebClient.DTOs
{
    public class AutorDto : AutorRemote
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }

    }
}
