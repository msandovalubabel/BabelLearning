﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Gateway.WebClient.DTOs
{
    public class AutorRemote
    {
        public string Id { get; set; }

    }
}
