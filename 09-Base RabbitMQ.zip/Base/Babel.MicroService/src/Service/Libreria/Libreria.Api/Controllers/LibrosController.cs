﻿using Libreria.Domain;
using Libreria.Persistence.Database;
using Microsoft.AspNetCore.Mvc;
using Servicios.RabbitMQ.Bus.BusRabbit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Libreria.Api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LibrosController : ControllerBase
    {
        private readonly IMongoRepository<LibroEntity> _libroRepository;
        private readonly IRabbitEventbus _eventBus;
        //public LibrosController(IMongoRepository<LibroEntity> libroRepository)
        //{
        //    _libroRepository = libroRepository;

        //}
        public LibrosController(IMongoRepository<LibroEntity> libroRepository, IRabbitEventbus eventBus)
        {
            _libroRepository = libroRepository;
            _eventBus = eventBus;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LibroEntity>>> Get()
        {
            return Ok(await _libroRepository.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LibroEntity>> GetById(string Id)
        {
            var libro = await _libroRepository.GetById(Id);
            return Ok(libro);
        }

        [HttpPost]
        public async Task Post(LibroEntity libro)
        {
            await _libroRepository.InsertDocument(libro);
           // _eventBus.Publish(new EmailEventoQueue("mauricio.sandoval@grupobabel.com", "Api.Libro", $"Se creó el Libro: {libro.Titulo}"));
        }
    }
}
