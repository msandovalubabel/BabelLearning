﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Catalog.Api.Filters
{
    public class LogAttribute:ActionFilterAttribute
    {
        
        private readonly ILogger<LogAttribute> _logger;
        public LogAttribute(ILogger<LogAttribute> logger)
        {
            _logger = logger;
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            IDictionary<string, object> actionparameters = context.ActionArguments;

            string tmpMsg = JsonSerializer.Serialize(actionparameters);
            var tmpObject = new
            {
                Controller = context.Controller.ToString(),
                Action = context.ActionDescriptor.DisplayName,
                ActionParameters = tmpMsg
            };
            _logger.LogInformation(JsonSerializer.Serialize(tmpObject));
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
            if(context.Exception!=null)
            {
                _logger.LogError(context.Exception, context.Exception.InnerException.Message);
            }
        }
    }
}
