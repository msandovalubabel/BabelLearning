﻿using Catalog.Domain;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Catalog.Persistence.Database.Configuration
{
    public class ProductConfiguration
    {
        public ProductConfiguration(EntityTypeBuilder<Product> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(x => x.ProductId);
            entityTypeBuilder.Property(x => x.Name).IsUnicode(false).IsRequired().HasMaxLength(100);
            entityTypeBuilder.Property(x => x.Description).IsRequired().HasMaxLength(500);
            entityTypeBuilder.Property(x => x.Price);
            //entityTypeBuilder.Property(x => x.Price).HasPrecision(18, 2);

            //Información default
            var products = new List<Product>();
            var random = new Random();
            for (int i = 1; i <= 1000; i++)
            {
                products.Add(new Product
                {
                    ProductId = i,
                    Name = $"Product {i}",
                    Description = $"Description for product {i}",
                    Price = random.Next(100, 2000)
                }
);
            }

            entityTypeBuilder.HasData(products);
        }
    }
}
