﻿using System;

namespace Customer.Domain
{
    public class Client
    {
        public int ClientId { get; set; }
        public string Name { get; set; }
    }
}
