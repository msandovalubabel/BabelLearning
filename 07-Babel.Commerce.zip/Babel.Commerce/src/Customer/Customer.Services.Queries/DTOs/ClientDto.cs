﻿namespace Customer.Service.Queries.DTOs
{
    public class ClientDto
    {
        public int ClientId { get; set; }
        public string Name { get; set; }
    }
}
