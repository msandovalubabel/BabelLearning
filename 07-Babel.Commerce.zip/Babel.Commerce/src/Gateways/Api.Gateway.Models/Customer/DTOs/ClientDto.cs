﻿namespace Api.Gateway.Models.Customer.DTOs
{
    public class ClientDto
    {
        public int ClientId { get; set; }
        public string Name { get; set; }
    }
}
