﻿using Azure.Messaging.ServiceBus;
using Catalog.Service.EventHandlers.Commands;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Catalog.Api.Services
{
    public class OrderStockUpdateService : BackgroundService
    {
        private readonly ServiceBusClient _client;
        private readonly int _refreshIntervalInSeconds;
        private readonly ILogger<OrderStockUpdateService> _logger;
        private IMediator _mediator;
        private readonly IServiceScopeFactory _serviceScopeFactory;

        public OrderStockUpdateService(ILogger<OrderStockUpdateService> logger, ServiceBusClient client, IServiceScopeFactory serviceScopeFactory)
        {
            
            _refreshIntervalInSeconds = 10;
            _logger = logger;
            _client = client;
            _serviceScopeFactory = serviceScopeFactory;

        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    ServiceBusReceiver receiver = _client.CreateReceiver("order_stock_update");
                    ServiceBusReceivedMessage receivedMessage = await receiver.ReceiveMessageAsync(cancellationToken: stoppingToken);
                    _logger.LogInformation("Read Queue order_stock_update");
                    if (receivedMessage!=null)
                    {
                        _logger.LogInformation("Procesing... Queue order_stock_update");

                        var command = JsonSerializer.Deserialize<ProductInStockUpdateCommand>(Encoding.UTF8.GetString(receivedMessage.Body));
                        using (var scope=_serviceScopeFactory.CreateScope())
                        {
                            _mediator = scope.ServiceProvider.GetRequiredService<IMediator>();
                            await _mediator.Publish(command, stoppingToken);
                        }                         

                        await receiver.CompleteMessageAsync(receivedMessage, stoppingToken);
                        _logger.LogInformation("Processed... Queue order_stock_update");
                    }
                   
                }
                catch (Exception ex)
                {

                    _logger.LogError(ex, "Error Procesing... Queue order_stock_update");

                }
                
                await Task.Delay(TimeSpan.FromSeconds(_refreshIntervalInSeconds), stoppingToken);

            }
        }
    }
}
