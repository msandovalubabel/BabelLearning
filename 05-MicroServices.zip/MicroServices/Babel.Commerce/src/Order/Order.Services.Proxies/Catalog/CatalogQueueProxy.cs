﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Order.Services.Proxies.Catalog.Command;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Order.Services.Proxies.Catalog
{    
    public class CatalogQueueProxy : ICatalogProxy
    {
        private readonly ILogger<CatalogQueueProxy> _logger;
        public readonly string _queueName;
        public readonly string _connectionString;

        public CatalogQueueProxy(IOptions<AzureServiceBus> azure, ILogger<CatalogQueueProxy> logger)
        {
            _connectionString = azure.Value.ConnectionString;
            _queueName = azure.Value.QueueName;
            _logger = logger;
        }
        public async Task UpdateStockAsync(ProductInStockUpdateCommand command)
        {
            // create the sender
            await using var client = new ServiceBusClient(_connectionString);

            // create the sender
            ServiceBusSender sender = client.CreateSender(_queueName);

            // Serialize message
            string body = JsonSerializer.Serialize(command);

            // create a message that we can send. UTF-8 encoding is used when providing a string.
            ServiceBusMessage message = new ServiceBusMessage(body);

            // send the message
            try
            {
                await sender.SendMessageAsync(message);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error create.... Queue order_stock_update");
                throw;
            }

        }
    }
}
