﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Catalog.Persistence.Database.Migrations
{
    public partial class InicialData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "Description for product 1", "Product 1", 1687m },
                    { 659, "Description for product 659", "Product 659", 309m },
                    { 660, "Description for product 660", "Product 660", 992m },
                    { 661, "Description for product 661", "Product 661", 1744m },
                    { 662, "Description for product 662", "Product 662", 1577m },
                    { 663, "Description for product 663", "Product 663", 1434m },
                    { 664, "Description for product 664", "Product 664", 194m },
                    { 665, "Description for product 665", "Product 665", 640m },
                    { 666, "Description for product 666", "Product 666", 1772m },
                    { 667, "Description for product 667", "Product 667", 883m },
                    { 668, "Description for product 668", "Product 668", 1255m },
                    { 669, "Description for product 669", "Product 669", 1347m },
                    { 670, "Description for product 670", "Product 670", 465m },
                    { 671, "Description for product 671", "Product 671", 446m },
                    { 672, "Description for product 672", "Product 672", 1691m },
                    { 673, "Description for product 673", "Product 673", 1643m },
                    { 674, "Description for product 674", "Product 674", 1266m },
                    { 675, "Description for product 675", "Product 675", 809m },
                    { 676, "Description for product 676", "Product 676", 241m },
                    { 677, "Description for product 677", "Product 677", 310m },
                    { 678, "Description for product 678", "Product 678", 1755m },
                    { 679, "Description for product 679", "Product 679", 1515m },
                    { 680, "Description for product 680", "Product 680", 638m },
                    { 681, "Description for product 681", "Product 681", 1329m },
                    { 682, "Description for product 682", "Product 682", 889m },
                    { 683, "Description for product 683", "Product 683", 1112m },
                    { 684, "Description for product 684", "Product 684", 1008m },
                    { 685, "Description for product 685", "Product 685", 1248m },
                    { 658, "Description for product 658", "Product 658", 1217m },
                    { 686, "Description for product 686", "Product 686", 837m },
                    { 657, "Description for product 657", "Product 657", 772m },
                    { 655, "Description for product 655", "Product 655", 566m },
                    { 628, "Description for product 628", "Product 628", 1163m },
                    { 629, "Description for product 629", "Product 629", 252m },
                    { 630, "Description for product 630", "Product 630", 800m },
                    { 631, "Description for product 631", "Product 631", 1225m },
                    { 632, "Description for product 632", "Product 632", 1811m },
                    { 633, "Description for product 633", "Product 633", 1345m },
                    { 634, "Description for product 634", "Product 634", 114m },
                    { 635, "Description for product 635", "Product 635", 1555m },
                    { 636, "Description for product 636", "Product 636", 907m },
                    { 637, "Description for product 637", "Product 637", 809m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 638, "Description for product 638", "Product 638", 367m },
                    { 639, "Description for product 639", "Product 639", 1273m },
                    { 640, "Description for product 640", "Product 640", 1411m },
                    { 641, "Description for product 641", "Product 641", 358m },
                    { 642, "Description for product 642", "Product 642", 1807m },
                    { 643, "Description for product 643", "Product 643", 1998m },
                    { 644, "Description for product 644", "Product 644", 1742m },
                    { 645, "Description for product 645", "Product 645", 936m },
                    { 646, "Description for product 646", "Product 646", 1484m },
                    { 647, "Description for product 647", "Product 647", 1778m },
                    { 648, "Description for product 648", "Product 648", 116m },
                    { 649, "Description for product 649", "Product 649", 150m },
                    { 650, "Description for product 650", "Product 650", 1244m },
                    { 651, "Description for product 651", "Product 651", 1551m },
                    { 652, "Description for product 652", "Product 652", 487m },
                    { 653, "Description for product 653", "Product 653", 1164m },
                    { 654, "Description for product 654", "Product 654", 835m },
                    { 656, "Description for product 656", "Product 656", 1352m },
                    { 687, "Description for product 687", "Product 687", 747m },
                    { 688, "Description for product 688", "Product 688", 609m },
                    { 689, "Description for product 689", "Product 689", 1548m },
                    { 722, "Description for product 722", "Product 722", 373m },
                    { 723, "Description for product 723", "Product 723", 1707m },
                    { 724, "Description for product 724", "Product 724", 1144m },
                    { 725, "Description for product 725", "Product 725", 330m },
                    { 726, "Description for product 726", "Product 726", 854m },
                    { 727, "Description for product 727", "Product 727", 1633m },
                    { 728, "Description for product 728", "Product 728", 1362m },
                    { 729, "Description for product 729", "Product 729", 1599m },
                    { 730, "Description for product 730", "Product 730", 128m },
                    { 731, "Description for product 731", "Product 731", 1769m },
                    { 732, "Description for product 732", "Product 732", 405m },
                    { 733, "Description for product 733", "Product 733", 653m },
                    { 734, "Description for product 734", "Product 734", 451m },
                    { 735, "Description for product 735", "Product 735", 1937m },
                    { 736, "Description for product 736", "Product 736", 807m },
                    { 737, "Description for product 737", "Product 737", 220m },
                    { 738, "Description for product 738", "Product 738", 1427m },
                    { 739, "Description for product 739", "Product 739", 210m },
                    { 740, "Description for product 740", "Product 740", 1388m },
                    { 741, "Description for product 741", "Product 741", 1993m },
                    { 742, "Description for product 742", "Product 742", 849m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 743, "Description for product 743", "Product 743", 583m },
                    { 744, "Description for product 744", "Product 744", 1223m },
                    { 745, "Description for product 745", "Product 745", 1160m },
                    { 746, "Description for product 746", "Product 746", 1218m },
                    { 747, "Description for product 747", "Product 747", 1890m },
                    { 748, "Description for product 748", "Product 748", 486m },
                    { 721, "Description for product 721", "Product 721", 1125m },
                    { 720, "Description for product 720", "Product 720", 1802m },
                    { 719, "Description for product 719", "Product 719", 945m },
                    { 718, "Description for product 718", "Product 718", 526m },
                    { 690, "Description for product 690", "Product 690", 302m },
                    { 691, "Description for product 691", "Product 691", 235m },
                    { 692, "Description for product 692", "Product 692", 1592m },
                    { 693, "Description for product 693", "Product 693", 157m },
                    { 694, "Description for product 694", "Product 694", 380m },
                    { 695, "Description for product 695", "Product 695", 1667m },
                    { 696, "Description for product 696", "Product 696", 780m },
                    { 697, "Description for product 697", "Product 697", 472m },
                    { 698, "Description for product 698", "Product 698", 1904m },
                    { 699, "Description for product 699", "Product 699", 1202m },
                    { 700, "Description for product 700", "Product 700", 1163m },
                    { 701, "Description for product 701", "Product 701", 700m },
                    { 702, "Description for product 702", "Product 702", 622m },
                    { 627, "Description for product 627", "Product 627", 905m },
                    { 703, "Description for product 703", "Product 703", 769m },
                    { 705, "Description for product 705", "Product 705", 897m },
                    { 706, "Description for product 706", "Product 706", 1860m },
                    { 707, "Description for product 707", "Product 707", 843m },
                    { 708, "Description for product 708", "Product 708", 1897m },
                    { 709, "Description for product 709", "Product 709", 126m },
                    { 710, "Description for product 710", "Product 710", 424m },
                    { 711, "Description for product 711", "Product 711", 1142m },
                    { 712, "Description for product 712", "Product 712", 1016m },
                    { 713, "Description for product 713", "Product 713", 1701m },
                    { 714, "Description for product 714", "Product 714", 1671m },
                    { 715, "Description for product 715", "Product 715", 1662m },
                    { 716, "Description for product 716", "Product 716", 954m },
                    { 717, "Description for product 717", "Product 717", 565m },
                    { 704, "Description for product 704", "Product 704", 1685m },
                    { 749, "Description for product 749", "Product 749", 717m },
                    { 626, "Description for product 626", "Product 626", 1108m },
                    { 624, "Description for product 624", "Product 624", 452m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 534, "Description for product 534", "Product 534", 1703m },
                    { 535, "Description for product 535", "Product 535", 1557m },
                    { 536, "Description for product 536", "Product 536", 888m },
                    { 537, "Description for product 537", "Product 537", 749m },
                    { 538, "Description for product 538", "Product 538", 837m },
                    { 539, "Description for product 539", "Product 539", 1573m },
                    { 540, "Description for product 540", "Product 540", 1735m },
                    { 541, "Description for product 541", "Product 541", 1968m },
                    { 542, "Description for product 542", "Product 542", 1397m },
                    { 543, "Description for product 543", "Product 543", 381m },
                    { 544, "Description for product 544", "Product 544", 1771m },
                    { 545, "Description for product 545", "Product 545", 1759m },
                    { 546, "Description for product 546", "Product 546", 663m },
                    { 547, "Description for product 547", "Product 547", 1176m },
                    { 548, "Description for product 548", "Product 548", 442m },
                    { 549, "Description for product 549", "Product 549", 1866m },
                    { 550, "Description for product 550", "Product 550", 158m },
                    { 551, "Description for product 551", "Product 551", 374m },
                    { 552, "Description for product 552", "Product 552", 1128m },
                    { 553, "Description for product 553", "Product 553", 141m },
                    { 554, "Description for product 554", "Product 554", 1104m },
                    { 555, "Description for product 555", "Product 555", 295m },
                    { 556, "Description for product 556", "Product 556", 1137m },
                    { 557, "Description for product 557", "Product 557", 1276m },
                    { 558, "Description for product 558", "Product 558", 1700m },
                    { 559, "Description for product 559", "Product 559", 1918m },
                    { 560, "Description for product 560", "Product 560", 350m },
                    { 533, "Description for product 533", "Product 533", 1897m },
                    { 561, "Description for product 561", "Product 561", 1435m },
                    { 532, "Description for product 532", "Product 532", 1436m },
                    { 530, "Description for product 530", "Product 530", 335m },
                    { 503, "Description for product 503", "Product 503", 1890m },
                    { 504, "Description for product 504", "Product 504", 1598m },
                    { 505, "Description for product 505", "Product 505", 504m },
                    { 506, "Description for product 506", "Product 506", 157m },
                    { 507, "Description for product 507", "Product 507", 924m },
                    { 508, "Description for product 508", "Product 508", 1425m },
                    { 509, "Description for product 509", "Product 509", 874m },
                    { 510, "Description for product 510", "Product 510", 1996m },
                    { 511, "Description for product 511", "Product 511", 780m },
                    { 512, "Description for product 512", "Product 512", 998m },
                    { 513, "Description for product 513", "Product 513", 709m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 514, "Description for product 514", "Product 514", 430m },
                    { 515, "Description for product 515", "Product 515", 523m },
                    { 516, "Description for product 516", "Product 516", 807m },
                    { 517, "Description for product 517", "Product 517", 562m },
                    { 518, "Description for product 518", "Product 518", 1960m },
                    { 519, "Description for product 519", "Product 519", 289m },
                    { 520, "Description for product 520", "Product 520", 278m },
                    { 521, "Description for product 521", "Product 521", 1827m },
                    { 522, "Description for product 522", "Product 522", 1834m },
                    { 523, "Description for product 523", "Product 523", 919m },
                    { 524, "Description for product 524", "Product 524", 289m },
                    { 525, "Description for product 525", "Product 525", 1680m },
                    { 526, "Description for product 526", "Product 526", 254m },
                    { 527, "Description for product 527", "Product 527", 722m },
                    { 528, "Description for product 528", "Product 528", 465m },
                    { 529, "Description for product 529", "Product 529", 1333m },
                    { 531, "Description for product 531", "Product 531", 128m },
                    { 562, "Description for product 562", "Product 562", 558m },
                    { 563, "Description for product 563", "Product 563", 192m },
                    { 564, "Description for product 564", "Product 564", 639m },
                    { 597, "Description for product 597", "Product 597", 1304m },
                    { 598, "Description for product 598", "Product 598", 1742m },
                    { 599, "Description for product 599", "Product 599", 1803m },
                    { 600, "Description for product 600", "Product 600", 515m },
                    { 601, "Description for product 601", "Product 601", 1561m },
                    { 602, "Description for product 602", "Product 602", 270m },
                    { 603, "Description for product 603", "Product 603", 1569m },
                    { 604, "Description for product 604", "Product 604", 331m },
                    { 605, "Description for product 605", "Product 605", 101m },
                    { 606, "Description for product 606", "Product 606", 649m },
                    { 607, "Description for product 607", "Product 607", 741m },
                    { 608, "Description for product 608", "Product 608", 1587m },
                    { 609, "Description for product 609", "Product 609", 894m },
                    { 610, "Description for product 610", "Product 610", 1765m },
                    { 611, "Description for product 611", "Product 611", 1583m },
                    { 612, "Description for product 612", "Product 612", 228m },
                    { 613, "Description for product 613", "Product 613", 1270m },
                    { 614, "Description for product 614", "Product 614", 902m },
                    { 615, "Description for product 615", "Product 615", 1272m },
                    { 616, "Description for product 616", "Product 616", 1156m },
                    { 617, "Description for product 617", "Product 617", 1958m },
                    { 618, "Description for product 618", "Product 618", 917m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 619, "Description for product 619", "Product 619", 678m },
                    { 620, "Description for product 620", "Product 620", 1067m },
                    { 621, "Description for product 621", "Product 621", 1948m },
                    { 622, "Description for product 622", "Product 622", 309m },
                    { 623, "Description for product 623", "Product 623", 1498m },
                    { 596, "Description for product 596", "Product 596", 1510m },
                    { 595, "Description for product 595", "Product 595", 400m },
                    { 594, "Description for product 594", "Product 594", 1323m },
                    { 593, "Description for product 593", "Product 593", 918m },
                    { 565, "Description for product 565", "Product 565", 1967m },
                    { 566, "Description for product 566", "Product 566", 1343m },
                    { 567, "Description for product 567", "Product 567", 1101m },
                    { 568, "Description for product 568", "Product 568", 1006m },
                    { 569, "Description for product 569", "Product 569", 872m },
                    { 570, "Description for product 570", "Product 570", 1634m },
                    { 571, "Description for product 571", "Product 571", 157m },
                    { 572, "Description for product 572", "Product 572", 1724m },
                    { 573, "Description for product 573", "Product 573", 486m },
                    { 574, "Description for product 574", "Product 574", 553m },
                    { 575, "Description for product 575", "Product 575", 310m },
                    { 576, "Description for product 576", "Product 576", 530m },
                    { 577, "Description for product 577", "Product 577", 1553m },
                    { 625, "Description for product 625", "Product 625", 122m },
                    { 578, "Description for product 578", "Product 578", 1148m },
                    { 580, "Description for product 580", "Product 580", 1116m },
                    { 581, "Description for product 581", "Product 581", 1077m },
                    { 582, "Description for product 582", "Product 582", 379m },
                    { 583, "Description for product 583", "Product 583", 599m },
                    { 584, "Description for product 584", "Product 584", 1274m },
                    { 585, "Description for product 585", "Product 585", 1960m },
                    { 586, "Description for product 586", "Product 586", 999m },
                    { 587, "Description for product 587", "Product 587", 1395m },
                    { 588, "Description for product 588", "Product 588", 892m },
                    { 589, "Description for product 589", "Product 589", 1507m },
                    { 590, "Description for product 590", "Product 590", 520m },
                    { 591, "Description for product 591", "Product 591", 1612m },
                    { 592, "Description for product 592", "Product 592", 1049m },
                    { 579, "Description for product 579", "Product 579", 530m },
                    { 502, "Description for product 502", "Product 502", 196m },
                    { 750, "Description for product 750", "Product 750", 812m },
                    { 752, "Description for product 752", "Product 752", 1945m },
                    { 909, "Description for product 909", "Product 909", 1299m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 910, "Description for product 910", "Product 910", 1288m },
                    { 911, "Description for product 911", "Product 911", 202m },
                    { 912, "Description for product 912", "Product 912", 1219m },
                    { 913, "Description for product 913", "Product 913", 1480m },
                    { 914, "Description for product 914", "Product 914", 1290m },
                    { 915, "Description for product 915", "Product 915", 454m },
                    { 916, "Description for product 916", "Product 916", 573m },
                    { 917, "Description for product 917", "Product 917", 119m },
                    { 918, "Description for product 918", "Product 918", 795m },
                    { 919, "Description for product 919", "Product 919", 873m },
                    { 920, "Description for product 920", "Product 920", 1159m },
                    { 921, "Description for product 921", "Product 921", 429m },
                    { 922, "Description for product 922", "Product 922", 441m },
                    { 923, "Description for product 923", "Product 923", 1254m },
                    { 924, "Description for product 924", "Product 924", 1480m },
                    { 925, "Description for product 925", "Product 925", 141m },
                    { 926, "Description for product 926", "Product 926", 622m },
                    { 927, "Description for product 927", "Product 927", 1667m },
                    { 928, "Description for product 928", "Product 928", 1526m },
                    { 929, "Description for product 929", "Product 929", 921m },
                    { 930, "Description for product 930", "Product 930", 1726m },
                    { 931, "Description for product 931", "Product 931", 909m },
                    { 932, "Description for product 932", "Product 932", 274m },
                    { 933, "Description for product 933", "Product 933", 1774m },
                    { 934, "Description for product 934", "Product 934", 1408m },
                    { 935, "Description for product 935", "Product 935", 466m },
                    { 908, "Description for product 908", "Product 908", 855m },
                    { 936, "Description for product 936", "Product 936", 507m },
                    { 907, "Description for product 907", "Product 907", 443m },
                    { 905, "Description for product 905", "Product 905", 1596m },
                    { 878, "Description for product 878", "Product 878", 485m },
                    { 879, "Description for product 879", "Product 879", 1149m },
                    { 880, "Description for product 880", "Product 880", 1506m },
                    { 881, "Description for product 881", "Product 881", 1383m },
                    { 882, "Description for product 882", "Product 882", 1537m },
                    { 883, "Description for product 883", "Product 883", 1362m },
                    { 884, "Description for product 884", "Product 884", 412m },
                    { 885, "Description for product 885", "Product 885", 1520m },
                    { 886, "Description for product 886", "Product 886", 880m },
                    { 887, "Description for product 887", "Product 887", 1002m },
                    { 888, "Description for product 888", "Product 888", 176m },
                    { 889, "Description for product 889", "Product 889", 825m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 890, "Description for product 890", "Product 890", 707m },
                    { 891, "Description for product 891", "Product 891", 816m },
                    { 892, "Description for product 892", "Product 892", 1963m },
                    { 893, "Description for product 893", "Product 893", 285m },
                    { 894, "Description for product 894", "Product 894", 1172m },
                    { 895, "Description for product 895", "Product 895", 725m },
                    { 896, "Description for product 896", "Product 896", 911m },
                    { 897, "Description for product 897", "Product 897", 835m },
                    { 898, "Description for product 898", "Product 898", 1370m },
                    { 899, "Description for product 899", "Product 899", 711m },
                    { 900, "Description for product 900", "Product 900", 1741m },
                    { 901, "Description for product 901", "Product 901", 1139m },
                    { 902, "Description for product 902", "Product 902", 975m },
                    { 903, "Description for product 903", "Product 903", 1540m },
                    { 904, "Description for product 904", "Product 904", 227m },
                    { 906, "Description for product 906", "Product 906", 1923m },
                    { 937, "Description for product 937", "Product 937", 1996m },
                    { 938, "Description for product 938", "Product 938", 1235m },
                    { 939, "Description for product 939", "Product 939", 815m },
                    { 972, "Description for product 972", "Product 972", 884m },
                    { 973, "Description for product 973", "Product 973", 1980m },
                    { 974, "Description for product 974", "Product 974", 1275m },
                    { 975, "Description for product 975", "Product 975", 722m },
                    { 976, "Description for product 976", "Product 976", 282m },
                    { 977, "Description for product 977", "Product 977", 1564m },
                    { 978, "Description for product 978", "Product 978", 1717m },
                    { 979, "Description for product 979", "Product 979", 976m },
                    { 980, "Description for product 980", "Product 980", 544m },
                    { 981, "Description for product 981", "Product 981", 138m },
                    { 982, "Description for product 982", "Product 982", 772m },
                    { 983, "Description for product 983", "Product 983", 809m },
                    { 984, "Description for product 984", "Product 984", 769m },
                    { 985, "Description for product 985", "Product 985", 934m },
                    { 986, "Description for product 986", "Product 986", 869m },
                    { 987, "Description for product 987", "Product 987", 1677m },
                    { 988, "Description for product 988", "Product 988", 322m },
                    { 989, "Description for product 989", "Product 989", 1997m },
                    { 990, "Description for product 990", "Product 990", 1668m },
                    { 991, "Description for product 991", "Product 991", 786m },
                    { 992, "Description for product 992", "Product 992", 1937m },
                    { 993, "Description for product 993", "Product 993", 1149m },
                    { 994, "Description for product 994", "Product 994", 1741m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 995, "Description for product 995", "Product 995", 1341m },
                    { 996, "Description for product 996", "Product 996", 1619m },
                    { 997, "Description for product 997", "Product 997", 313m },
                    { 998, "Description for product 998", "Product 998", 1305m },
                    { 971, "Description for product 971", "Product 971", 577m },
                    { 970, "Description for product 970", "Product 970", 1947m },
                    { 969, "Description for product 969", "Product 969", 924m },
                    { 968, "Description for product 968", "Product 968", 171m },
                    { 940, "Description for product 940", "Product 940", 1597m },
                    { 941, "Description for product 941", "Product 941", 536m },
                    { 942, "Description for product 942", "Product 942", 247m },
                    { 943, "Description for product 943", "Product 943", 877m },
                    { 944, "Description for product 944", "Product 944", 1537m },
                    { 945, "Description for product 945", "Product 945", 604m },
                    { 946, "Description for product 946", "Product 946", 1597m },
                    { 947, "Description for product 947", "Product 947", 583m },
                    { 948, "Description for product 948", "Product 948", 994m },
                    { 949, "Description for product 949", "Product 949", 817m },
                    { 950, "Description for product 950", "Product 950", 251m },
                    { 951, "Description for product 951", "Product 951", 892m },
                    { 952, "Description for product 952", "Product 952", 140m },
                    { 877, "Description for product 877", "Product 877", 1544m },
                    { 953, "Description for product 953", "Product 953", 596m },
                    { 955, "Description for product 955", "Product 955", 1411m },
                    { 956, "Description for product 956", "Product 956", 798m },
                    { 957, "Description for product 957", "Product 957", 1721m },
                    { 958, "Description for product 958", "Product 958", 159m },
                    { 959, "Description for product 959", "Product 959", 185m },
                    { 960, "Description for product 960", "Product 960", 1074m },
                    { 961, "Description for product 961", "Product 961", 355m },
                    { 962, "Description for product 962", "Product 962", 916m },
                    { 963, "Description for product 963", "Product 963", 1933m },
                    { 964, "Description for product 964", "Product 964", 1572m },
                    { 965, "Description for product 965", "Product 965", 478m },
                    { 966, "Description for product 966", "Product 966", 1928m },
                    { 967, "Description for product 967", "Product 967", 1444m },
                    { 954, "Description for product 954", "Product 954", 1551m },
                    { 751, "Description for product 751", "Product 751", 315m },
                    { 876, "Description for product 876", "Product 876", 1645m },
                    { 874, "Description for product 874", "Product 874", 1547m },
                    { 784, "Description for product 784", "Product 784", 887m },
                    { 785, "Description for product 785", "Product 785", 1813m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 786, "Description for product 786", "Product 786", 1823m },
                    { 787, "Description for product 787", "Product 787", 1346m },
                    { 788, "Description for product 788", "Product 788", 1254m },
                    { 789, "Description for product 789", "Product 789", 413m },
                    { 790, "Description for product 790", "Product 790", 1610m },
                    { 791, "Description for product 791", "Product 791", 1891m },
                    { 792, "Description for product 792", "Product 792", 595m },
                    { 793, "Description for product 793", "Product 793", 1972m },
                    { 794, "Description for product 794", "Product 794", 166m },
                    { 795, "Description for product 795", "Product 795", 1162m },
                    { 796, "Description for product 796", "Product 796", 612m },
                    { 797, "Description for product 797", "Product 797", 552m },
                    { 798, "Description for product 798", "Product 798", 585m },
                    { 799, "Description for product 799", "Product 799", 668m },
                    { 800, "Description for product 800", "Product 800", 424m },
                    { 801, "Description for product 801", "Product 801", 856m },
                    { 802, "Description for product 802", "Product 802", 641m },
                    { 803, "Description for product 803", "Product 803", 753m },
                    { 804, "Description for product 804", "Product 804", 1761m },
                    { 805, "Description for product 805", "Product 805", 1977m },
                    { 806, "Description for product 806", "Product 806", 1177m },
                    { 807, "Description for product 807", "Product 807", 1630m },
                    { 808, "Description for product 808", "Product 808", 1502m },
                    { 809, "Description for product 809", "Product 809", 1590m },
                    { 810, "Description for product 810", "Product 810", 1762m },
                    { 783, "Description for product 783", "Product 783", 744m },
                    { 811, "Description for product 811", "Product 811", 636m },
                    { 782, "Description for product 782", "Product 782", 1246m },
                    { 780, "Description for product 780", "Product 780", 1111m },
                    { 753, "Description for product 753", "Product 753", 1059m },
                    { 754, "Description for product 754", "Product 754", 1399m },
                    { 755, "Description for product 755", "Product 755", 138m },
                    { 756, "Description for product 756", "Product 756", 427m },
                    { 757, "Description for product 757", "Product 757", 915m },
                    { 758, "Description for product 758", "Product 758", 1624m },
                    { 759, "Description for product 759", "Product 759", 1455m },
                    { 760, "Description for product 760", "Product 760", 143m },
                    { 761, "Description for product 761", "Product 761", 326m },
                    { 762, "Description for product 762", "Product 762", 1481m },
                    { 763, "Description for product 763", "Product 763", 397m },
                    { 764, "Description for product 764", "Product 764", 1997m },
                    { 765, "Description for product 765", "Product 765", 655m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 766, "Description for product 766", "Product 766", 836m },
                    { 767, "Description for product 767", "Product 767", 462m },
                    { 768, "Description for product 768", "Product 768", 1349m },
                    { 769, "Description for product 769", "Product 769", 1733m },
                    { 770, "Description for product 770", "Product 770", 955m },
                    { 771, "Description for product 771", "Product 771", 834m },
                    { 772, "Description for product 772", "Product 772", 1138m },
                    { 773, "Description for product 773", "Product 773", 415m },
                    { 774, "Description for product 774", "Product 774", 1556m },
                    { 775, "Description for product 775", "Product 775", 1809m },
                    { 776, "Description for product 776", "Product 776", 375m },
                    { 777, "Description for product 777", "Product 777", 1790m },
                    { 778, "Description for product 778", "Product 778", 583m },
                    { 779, "Description for product 779", "Product 779", 1984m },
                    { 781, "Description for product 781", "Product 781", 963m },
                    { 812, "Description for product 812", "Product 812", 432m },
                    { 813, "Description for product 813", "Product 813", 1640m },
                    { 814, "Description for product 814", "Product 814", 443m },
                    { 847, "Description for product 847", "Product 847", 955m },
                    { 848, "Description for product 848", "Product 848", 1628m },
                    { 849, "Description for product 849", "Product 849", 986m },
                    { 850, "Description for product 850", "Product 850", 182m },
                    { 851, "Description for product 851", "Product 851", 1776m },
                    { 852, "Description for product 852", "Product 852", 1042m },
                    { 853, "Description for product 853", "Product 853", 402m },
                    { 854, "Description for product 854", "Product 854", 1837m },
                    { 855, "Description for product 855", "Product 855", 934m },
                    { 856, "Description for product 856", "Product 856", 1647m },
                    { 857, "Description for product 857", "Product 857", 1605m },
                    { 858, "Description for product 858", "Product 858", 629m },
                    { 859, "Description for product 859", "Product 859", 797m },
                    { 860, "Description for product 860", "Product 860", 1738m },
                    { 861, "Description for product 861", "Product 861", 111m },
                    { 862, "Description for product 862", "Product 862", 1381m },
                    { 863, "Description for product 863", "Product 863", 1107m },
                    { 864, "Description for product 864", "Product 864", 393m },
                    { 865, "Description for product 865", "Product 865", 1939m },
                    { 866, "Description for product 866", "Product 866", 1332m },
                    { 867, "Description for product 867", "Product 867", 518m },
                    { 868, "Description for product 868", "Product 868", 1979m },
                    { 869, "Description for product 869", "Product 869", 188m },
                    { 870, "Description for product 870", "Product 870", 858m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 871, "Description for product 871", "Product 871", 586m },
                    { 872, "Description for product 872", "Product 872", 1853m },
                    { 873, "Description for product 873", "Product 873", 699m },
                    { 846, "Description for product 846", "Product 846", 1558m },
                    { 845, "Description for product 845", "Product 845", 1073m },
                    { 844, "Description for product 844", "Product 844", 650m },
                    { 843, "Description for product 843", "Product 843", 1663m },
                    { 815, "Description for product 815", "Product 815", 1180m },
                    { 816, "Description for product 816", "Product 816", 1079m },
                    { 817, "Description for product 817", "Product 817", 836m },
                    { 818, "Description for product 818", "Product 818", 1509m },
                    { 819, "Description for product 819", "Product 819", 283m },
                    { 820, "Description for product 820", "Product 820", 831m },
                    { 821, "Description for product 821", "Product 821", 1489m },
                    { 822, "Description for product 822", "Product 822", 1208m },
                    { 823, "Description for product 823", "Product 823", 1036m },
                    { 824, "Description for product 824", "Product 824", 223m },
                    { 825, "Description for product 825", "Product 825", 1064m },
                    { 826, "Description for product 826", "Product 826", 339m },
                    { 827, "Description for product 827", "Product 827", 1165m },
                    { 875, "Description for product 875", "Product 875", 638m },
                    { 828, "Description for product 828", "Product 828", 348m },
                    { 830, "Description for product 830", "Product 830", 1296m },
                    { 831, "Description for product 831", "Product 831", 1823m },
                    { 832, "Description for product 832", "Product 832", 1304m },
                    { 833, "Description for product 833", "Product 833", 1914m },
                    { 834, "Description for product 834", "Product 834", 1660m },
                    { 835, "Description for product 835", "Product 835", 355m },
                    { 836, "Description for product 836", "Product 836", 421m },
                    { 837, "Description for product 837", "Product 837", 593m },
                    { 838, "Description for product 838", "Product 838", 983m },
                    { 839, "Description for product 839", "Product 839", 910m },
                    { 840, "Description for product 840", "Product 840", 736m },
                    { 841, "Description for product 841", "Product 841", 293m },
                    { 842, "Description for product 842", "Product 842", 1843m },
                    { 829, "Description for product 829", "Product 829", 494m },
                    { 501, "Description for product 501", "Product 501", 972m },
                    { 500, "Description for product 500", "Product 500", 122m },
                    { 499, "Description for product 499", "Product 499", 1282m },
                    { 158, "Description for product 158", "Product 158", 1221m },
                    { 159, "Description for product 159", "Product 159", 1425m },
                    { 160, "Description for product 160", "Product 160", 298m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 161, "Description for product 161", "Product 161", 554m },
                    { 162, "Description for product 162", "Product 162", 293m },
                    { 163, "Description for product 163", "Product 163", 911m },
                    { 164, "Description for product 164", "Product 164", 1334m },
                    { 165, "Description for product 165", "Product 165", 1044m },
                    { 166, "Description for product 166", "Product 166", 1146m },
                    { 167, "Description for product 167", "Product 167", 1075m },
                    { 168, "Description for product 168", "Product 168", 1505m },
                    { 169, "Description for product 169", "Product 169", 1674m },
                    { 170, "Description for product 170", "Product 170", 1597m },
                    { 171, "Description for product 171", "Product 171", 789m },
                    { 172, "Description for product 172", "Product 172", 954m },
                    { 173, "Description for product 173", "Product 173", 1043m },
                    { 174, "Description for product 174", "Product 174", 771m },
                    { 175, "Description for product 175", "Product 175", 704m },
                    { 176, "Description for product 176", "Product 176", 1671m },
                    { 177, "Description for product 177", "Product 177", 954m },
                    { 178, "Description for product 178", "Product 178", 443m },
                    { 179, "Description for product 179", "Product 179", 747m },
                    { 180, "Description for product 180", "Product 180", 1984m },
                    { 181, "Description for product 181", "Product 181", 382m },
                    { 182, "Description for product 182", "Product 182", 1668m },
                    { 183, "Description for product 183", "Product 183", 531m },
                    { 184, "Description for product 184", "Product 184", 956m },
                    { 157, "Description for product 157", "Product 157", 1981m },
                    { 185, "Description for product 185", "Product 185", 839m },
                    { 156, "Description for product 156", "Product 156", 1913m },
                    { 154, "Description for product 154", "Product 154", 1232m },
                    { 127, "Description for product 127", "Product 127", 940m },
                    { 128, "Description for product 128", "Product 128", 492m },
                    { 129, "Description for product 129", "Product 129", 696m },
                    { 130, "Description for product 130", "Product 130", 1682m },
                    { 131, "Description for product 131", "Product 131", 1644m },
                    { 132, "Description for product 132", "Product 132", 1072m },
                    { 133, "Description for product 133", "Product 133", 366m },
                    { 134, "Description for product 134", "Product 134", 1471m },
                    { 135, "Description for product 135", "Product 135", 1042m },
                    { 136, "Description for product 136", "Product 136", 848m },
                    { 137, "Description for product 137", "Product 137", 608m },
                    { 138, "Description for product 138", "Product 138", 971m },
                    { 139, "Description for product 139", "Product 139", 848m },
                    { 140, "Description for product 140", "Product 140", 1686m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 141, "Description for product 141", "Product 141", 1725m },
                    { 142, "Description for product 142", "Product 142", 221m },
                    { 143, "Description for product 143", "Product 143", 274m },
                    { 144, "Description for product 144", "Product 144", 1631m },
                    { 145, "Description for product 145", "Product 145", 745m },
                    { 146, "Description for product 146", "Product 146", 1978m },
                    { 147, "Description for product 147", "Product 147", 1409m },
                    { 148, "Description for product 148", "Product 148", 1271m },
                    { 149, "Description for product 149", "Product 149", 1961m },
                    { 150, "Description for product 150", "Product 150", 1739m },
                    { 151, "Description for product 151", "Product 151", 942m },
                    { 152, "Description for product 152", "Product 152", 955m },
                    { 153, "Description for product 153", "Product 153", 1669m },
                    { 155, "Description for product 155", "Product 155", 463m },
                    { 186, "Description for product 186", "Product 186", 788m },
                    { 187, "Description for product 187", "Product 187", 1402m },
                    { 188, "Description for product 188", "Product 188", 1133m },
                    { 221, "Description for product 221", "Product 221", 1743m },
                    { 222, "Description for product 222", "Product 222", 1941m },
                    { 223, "Description for product 223", "Product 223", 498m },
                    { 224, "Description for product 224", "Product 224", 645m },
                    { 225, "Description for product 225", "Product 225", 831m },
                    { 226, "Description for product 226", "Product 226", 1403m },
                    { 227, "Description for product 227", "Product 227", 1408m },
                    { 228, "Description for product 228", "Product 228", 493m },
                    { 229, "Description for product 229", "Product 229", 1539m },
                    { 230, "Description for product 230", "Product 230", 1171m },
                    { 231, "Description for product 231", "Product 231", 460m },
                    { 232, "Description for product 232", "Product 232", 114m },
                    { 233, "Description for product 233", "Product 233", 1755m },
                    { 234, "Description for product 234", "Product 234", 1147m },
                    { 235, "Description for product 235", "Product 235", 1082m },
                    { 236, "Description for product 236", "Product 236", 478m },
                    { 237, "Description for product 237", "Product 237", 171m },
                    { 238, "Description for product 238", "Product 238", 167m },
                    { 239, "Description for product 239", "Product 239", 1905m },
                    { 240, "Description for product 240", "Product 240", 851m },
                    { 241, "Description for product 241", "Product 241", 877m },
                    { 242, "Description for product 242", "Product 242", 504m },
                    { 243, "Description for product 243", "Product 243", 605m },
                    { 244, "Description for product 244", "Product 244", 415m },
                    { 245, "Description for product 245", "Product 245", 170m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 246, "Description for product 246", "Product 246", 1227m },
                    { 247, "Description for product 247", "Product 247", 911m },
                    { 220, "Description for product 220", "Product 220", 355m },
                    { 219, "Description for product 219", "Product 219", 594m },
                    { 218, "Description for product 218", "Product 218", 1954m },
                    { 217, "Description for product 217", "Product 217", 1761m },
                    { 189, "Description for product 189", "Product 189", 1107m },
                    { 190, "Description for product 190", "Product 190", 1129m },
                    { 191, "Description for product 191", "Product 191", 866m },
                    { 192, "Description for product 192", "Product 192", 1386m },
                    { 193, "Description for product 193", "Product 193", 1546m },
                    { 194, "Description for product 194", "Product 194", 650m },
                    { 195, "Description for product 195", "Product 195", 1232m },
                    { 196, "Description for product 196", "Product 196", 1532m },
                    { 197, "Description for product 197", "Product 197", 1310m },
                    { 198, "Description for product 198", "Product 198", 940m },
                    { 199, "Description for product 199", "Product 199", 687m },
                    { 200, "Description for product 200", "Product 200", 1599m },
                    { 201, "Description for product 201", "Product 201", 1002m },
                    { 126, "Description for product 126", "Product 126", 1691m },
                    { 202, "Description for product 202", "Product 202", 1903m },
                    { 204, "Description for product 204", "Product 204", 464m },
                    { 205, "Description for product 205", "Product 205", 1050m },
                    { 206, "Description for product 206", "Product 206", 1988m },
                    { 207, "Description for product 207", "Product 207", 1911m },
                    { 208, "Description for product 208", "Product 208", 998m },
                    { 209, "Description for product 209", "Product 209", 627m },
                    { 210, "Description for product 210", "Product 210", 792m },
                    { 211, "Description for product 211", "Product 211", 1058m },
                    { 212, "Description for product 212", "Product 212", 1638m },
                    { 213, "Description for product 213", "Product 213", 574m },
                    { 214, "Description for product 214", "Product 214", 1441m },
                    { 215, "Description for product 215", "Product 215", 1916m },
                    { 216, "Description for product 216", "Product 216", 885m },
                    { 203, "Description for product 203", "Product 203", 1597m },
                    { 248, "Description for product 248", "Product 248", 204m },
                    { 125, "Description for product 125", "Product 125", 1962m },
                    { 123, "Description for product 123", "Product 123", 1975m },
                    { 33, "Description for product 33", "Product 33", 559m },
                    { 34, "Description for product 34", "Product 34", 1201m },
                    { 35, "Description for product 35", "Product 35", 1982m },
                    { 36, "Description for product 36", "Product 36", 492m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 37, "Description for product 37", "Product 37", 892m },
                    { 38, "Description for product 38", "Product 38", 592m },
                    { 39, "Description for product 39", "Product 39", 1458m },
                    { 40, "Description for product 40", "Product 40", 1358m },
                    { 41, "Description for product 41", "Product 41", 854m },
                    { 42, "Description for product 42", "Product 42", 1179m },
                    { 43, "Description for product 43", "Product 43", 1468m },
                    { 44, "Description for product 44", "Product 44", 306m },
                    { 45, "Description for product 45", "Product 45", 1579m },
                    { 46, "Description for product 46", "Product 46", 1263m },
                    { 47, "Description for product 47", "Product 47", 252m },
                    { 48, "Description for product 48", "Product 48", 772m },
                    { 49, "Description for product 49", "Product 49", 671m },
                    { 50, "Description for product 50", "Product 50", 1869m },
                    { 51, "Description for product 51", "Product 51", 225m },
                    { 52, "Description for product 52", "Product 52", 1386m },
                    { 53, "Description for product 53", "Product 53", 1141m },
                    { 54, "Description for product 54", "Product 54", 1367m },
                    { 55, "Description for product 55", "Product 55", 980m },
                    { 56, "Description for product 56", "Product 56", 1218m },
                    { 57, "Description for product 57", "Product 57", 1172m },
                    { 58, "Description for product 58", "Product 58", 605m },
                    { 59, "Description for product 59", "Product 59", 703m },
                    { 32, "Description for product 32", "Product 32", 771m },
                    { 60, "Description for product 60", "Product 60", 1151m },
                    { 31, "Description for product 31", "Product 31", 1698m },
                    { 29, "Description for product 29", "Product 29", 609m },
                    { 2, "Description for product 2", "Product 2", 1207m },
                    { 3, "Description for product 3", "Product 3", 1712m },
                    { 4, "Description for product 4", "Product 4", 1852m },
                    { 5, "Description for product 5", "Product 5", 109m },
                    { 6, "Description for product 6", "Product 6", 216m },
                    { 7, "Description for product 7", "Product 7", 1017m },
                    { 8, "Description for product 8", "Product 8", 1041m },
                    { 9, "Description for product 9", "Product 9", 647m },
                    { 10, "Description for product 10", "Product 10", 441m },
                    { 11, "Description for product 11", "Product 11", 194m },
                    { 12, "Description for product 12", "Product 12", 780m },
                    { 13, "Description for product 13", "Product 13", 1397m },
                    { 14, "Description for product 14", "Product 14", 239m },
                    { 15, "Description for product 15", "Product 15", 1675m },
                    { 16, "Description for product 16", "Product 16", 870m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 17, "Description for product 17", "Product 17", 1322m },
                    { 18, "Description for product 18", "Product 18", 258m },
                    { 19, "Description for product 19", "Product 19", 992m },
                    { 20, "Description for product 20", "Product 20", 1205m },
                    { 21, "Description for product 21", "Product 21", 1471m },
                    { 22, "Description for product 22", "Product 22", 568m },
                    { 23, "Description for product 23", "Product 23", 135m },
                    { 24, "Description for product 24", "Product 24", 1207m },
                    { 25, "Description for product 25", "Product 25", 1249m },
                    { 26, "Description for product 26", "Product 26", 958m },
                    { 27, "Description for product 27", "Product 27", 1795m },
                    { 28, "Description for product 28", "Product 28", 931m },
                    { 30, "Description for product 30", "Product 30", 1207m },
                    { 61, "Description for product 61", "Product 61", 420m },
                    { 62, "Description for product 62", "Product 62", 186m },
                    { 63, "Description for product 63", "Product 63", 532m },
                    { 96, "Description for product 96", "Product 96", 768m },
                    { 97, "Description for product 97", "Product 97", 747m },
                    { 98, "Description for product 98", "Product 98", 128m },
                    { 99, "Description for product 99", "Product 99", 1563m },
                    { 100, "Description for product 100", "Product 100", 256m },
                    { 101, "Description for product 101", "Product 101", 1042m },
                    { 102, "Description for product 102", "Product 102", 1957m },
                    { 103, "Description for product 103", "Product 103", 615m },
                    { 104, "Description for product 104", "Product 104", 1388m },
                    { 105, "Description for product 105", "Product 105", 1890m },
                    { 106, "Description for product 106", "Product 106", 1395m },
                    { 107, "Description for product 107", "Product 107", 686m },
                    { 108, "Description for product 108", "Product 108", 1507m },
                    { 109, "Description for product 109", "Product 109", 1016m },
                    { 110, "Description for product 110", "Product 110", 688m },
                    { 111, "Description for product 111", "Product 111", 218m },
                    { 112, "Description for product 112", "Product 112", 1342m },
                    { 113, "Description for product 113", "Product 113", 977m },
                    { 114, "Description for product 114", "Product 114", 717m },
                    { 115, "Description for product 115", "Product 115", 445m },
                    { 116, "Description for product 116", "Product 116", 1297m },
                    { 117, "Description for product 117", "Product 117", 1826m },
                    { 118, "Description for product 118", "Product 118", 1792m },
                    { 119, "Description for product 119", "Product 119", 458m },
                    { 120, "Description for product 120", "Product 120", 430m },
                    { 121, "Description for product 121", "Product 121", 1792m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 122, "Description for product 122", "Product 122", 1129m },
                    { 95, "Description for product 95", "Product 95", 1037m },
                    { 94, "Description for product 94", "Product 94", 407m },
                    { 93, "Description for product 93", "Product 93", 1889m },
                    { 92, "Description for product 92", "Product 92", 386m },
                    { 64, "Description for product 64", "Product 64", 1440m },
                    { 65, "Description for product 65", "Product 65", 742m },
                    { 66, "Description for product 66", "Product 66", 1422m },
                    { 67, "Description for product 67", "Product 67", 320m },
                    { 68, "Description for product 68", "Product 68", 295m },
                    { 69, "Description for product 69", "Product 69", 257m },
                    { 70, "Description for product 70", "Product 70", 1282m },
                    { 71, "Description for product 71", "Product 71", 1978m },
                    { 72, "Description for product 72", "Product 72", 829m },
                    { 73, "Description for product 73", "Product 73", 800m },
                    { 74, "Description for product 74", "Product 74", 1634m },
                    { 75, "Description for product 75", "Product 75", 450m },
                    { 76, "Description for product 76", "Product 76", 391m },
                    { 124, "Description for product 124", "Product 124", 1393m },
                    { 77, "Description for product 77", "Product 77", 1100m },
                    { 79, "Description for product 79", "Product 79", 1628m },
                    { 80, "Description for product 80", "Product 80", 1985m },
                    { 81, "Description for product 81", "Product 81", 805m },
                    { 82, "Description for product 82", "Product 82", 1123m },
                    { 83, "Description for product 83", "Product 83", 360m },
                    { 84, "Description for product 84", "Product 84", 739m },
                    { 85, "Description for product 85", "Product 85", 1082m },
                    { 86, "Description for product 86", "Product 86", 412m },
                    { 87, "Description for product 87", "Product 87", 1629m },
                    { 88, "Description for product 88", "Product 88", 1191m },
                    { 89, "Description for product 89", "Product 89", 320m },
                    { 90, "Description for product 90", "Product 90", 864m },
                    { 91, "Description for product 91", "Product 91", 1320m },
                    { 78, "Description for product 78", "Product 78", 1829m },
                    { 249, "Description for product 249", "Product 249", 733m },
                    { 250, "Description for product 250", "Product 250", 446m },
                    { 251, "Description for product 251", "Product 251", 1771m },
                    { 409, "Description for product 409", "Product 409", 1229m },
                    { 410, "Description for product 410", "Product 410", 1443m },
                    { 411, "Description for product 411", "Product 411", 899m },
                    { 412, "Description for product 412", "Product 412", 1893m },
                    { 413, "Description for product 413", "Product 413", 1467m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 414, "Description for product 414", "Product 414", 1515m },
                    { 415, "Description for product 415", "Product 415", 883m },
                    { 416, "Description for product 416", "Product 416", 161m },
                    { 417, "Description for product 417", "Product 417", 929m },
                    { 418, "Description for product 418", "Product 418", 455m },
                    { 419, "Description for product 419", "Product 419", 312m },
                    { 420, "Description for product 420", "Product 420", 708m },
                    { 421, "Description for product 421", "Product 421", 146m },
                    { 422, "Description for product 422", "Product 422", 1880m },
                    { 423, "Description for product 423", "Product 423", 1433m },
                    { 424, "Description for product 424", "Product 424", 398m },
                    { 425, "Description for product 425", "Product 425", 392m },
                    { 426, "Description for product 426", "Product 426", 1668m },
                    { 427, "Description for product 427", "Product 427", 1159m },
                    { 428, "Description for product 428", "Product 428", 1178m },
                    { 429, "Description for product 429", "Product 429", 423m },
                    { 430, "Description for product 430", "Product 430", 1246m },
                    { 431, "Description for product 431", "Product 431", 472m },
                    { 432, "Description for product 432", "Product 432", 348m },
                    { 433, "Description for product 433", "Product 433", 1002m },
                    { 434, "Description for product 434", "Product 434", 880m },
                    { 435, "Description for product 435", "Product 435", 886m },
                    { 408, "Description for product 408", "Product 408", 363m },
                    { 436, "Description for product 436", "Product 436", 1641m },
                    { 407, "Description for product 407", "Product 407", 1977m },
                    { 405, "Description for product 405", "Product 405", 1076m },
                    { 378, "Description for product 378", "Product 378", 1457m },
                    { 379, "Description for product 379", "Product 379", 1940m },
                    { 380, "Description for product 380", "Product 380", 1114m },
                    { 381, "Description for product 381", "Product 381", 1153m },
                    { 382, "Description for product 382", "Product 382", 855m },
                    { 383, "Description for product 383", "Product 383", 687m },
                    { 384, "Description for product 384", "Product 384", 775m },
                    { 385, "Description for product 385", "Product 385", 619m },
                    { 386, "Description for product 386", "Product 386", 1613m },
                    { 387, "Description for product 387", "Product 387", 1291m },
                    { 388, "Description for product 388", "Product 388", 1442m },
                    { 389, "Description for product 389", "Product 389", 1696m },
                    { 390, "Description for product 390", "Product 390", 1472m },
                    { 391, "Description for product 391", "Product 391", 1756m },
                    { 392, "Description for product 392", "Product 392", 250m },
                    { 393, "Description for product 393", "Product 393", 134m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 394, "Description for product 394", "Product 394", 1625m },
                    { 395, "Description for product 395", "Product 395", 507m },
                    { 396, "Description for product 396", "Product 396", 381m },
                    { 397, "Description for product 397", "Product 397", 1935m },
                    { 398, "Description for product 398", "Product 398", 1738m },
                    { 399, "Description for product 399", "Product 399", 554m },
                    { 400, "Description for product 400", "Product 400", 1159m },
                    { 401, "Description for product 401", "Product 401", 327m },
                    { 402, "Description for product 402", "Product 402", 1511m },
                    { 403, "Description for product 403", "Product 403", 733m },
                    { 404, "Description for product 404", "Product 404", 1153m },
                    { 406, "Description for product 406", "Product 406", 506m },
                    { 437, "Description for product 437", "Product 437", 221m },
                    { 438, "Description for product 438", "Product 438", 1533m },
                    { 439, "Description for product 439", "Product 439", 1699m },
                    { 472, "Description for product 472", "Product 472", 1395m },
                    { 473, "Description for product 473", "Product 473", 756m },
                    { 474, "Description for product 474", "Product 474", 199m },
                    { 475, "Description for product 475", "Product 475", 1072m },
                    { 476, "Description for product 476", "Product 476", 1117m },
                    { 477, "Description for product 477", "Product 477", 1666m },
                    { 478, "Description for product 478", "Product 478", 1179m },
                    { 479, "Description for product 479", "Product 479", 1725m },
                    { 480, "Description for product 480", "Product 480", 530m },
                    { 481, "Description for product 481", "Product 481", 985m },
                    { 482, "Description for product 482", "Product 482", 640m },
                    { 483, "Description for product 483", "Product 483", 436m },
                    { 484, "Description for product 484", "Product 484", 1978m },
                    { 485, "Description for product 485", "Product 485", 1793m },
                    { 486, "Description for product 486", "Product 486", 892m },
                    { 487, "Description for product 487", "Product 487", 823m },
                    { 488, "Description for product 488", "Product 488", 1155m },
                    { 489, "Description for product 489", "Product 489", 1767m },
                    { 490, "Description for product 490", "Product 490", 539m },
                    { 491, "Description for product 491", "Product 491", 1562m },
                    { 492, "Description for product 492", "Product 492", 1786m },
                    { 493, "Description for product 493", "Product 493", 773m },
                    { 494, "Description for product 494", "Product 494", 390m },
                    { 495, "Description for product 495", "Product 495", 866m },
                    { 496, "Description for product 496", "Product 496", 836m },
                    { 497, "Description for product 497", "Product 497", 1089m },
                    { 498, "Description for product 498", "Product 498", 330m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 471, "Description for product 471", "Product 471", 1940m },
                    { 470, "Description for product 470", "Product 470", 1242m },
                    { 469, "Description for product 469", "Product 469", 728m },
                    { 468, "Description for product 468", "Product 468", 686m },
                    { 440, "Description for product 440", "Product 440", 213m },
                    { 441, "Description for product 441", "Product 441", 1636m },
                    { 442, "Description for product 442", "Product 442", 1028m },
                    { 443, "Description for product 443", "Product 443", 313m },
                    { 444, "Description for product 444", "Product 444", 353m },
                    { 445, "Description for product 445", "Product 445", 673m },
                    { 446, "Description for product 446", "Product 446", 1862m },
                    { 447, "Description for product 447", "Product 447", 782m },
                    { 448, "Description for product 448", "Product 448", 619m },
                    { 449, "Description for product 449", "Product 449", 841m },
                    { 450, "Description for product 450", "Product 450", 445m },
                    { 451, "Description for product 451", "Product 451", 1452m },
                    { 452, "Description for product 452", "Product 452", 1580m },
                    { 377, "Description for product 377", "Product 377", 1987m },
                    { 453, "Description for product 453", "Product 453", 1525m },
                    { 455, "Description for product 455", "Product 455", 1113m },
                    { 456, "Description for product 456", "Product 456", 447m },
                    { 457, "Description for product 457", "Product 457", 178m },
                    { 458, "Description for product 458", "Product 458", 435m },
                    { 459, "Description for product 459", "Product 459", 860m },
                    { 460, "Description for product 460", "Product 460", 1408m },
                    { 461, "Description for product 461", "Product 461", 1347m },
                    { 462, "Description for product 462", "Product 462", 899m },
                    { 463, "Description for product 463", "Product 463", 1939m },
                    { 464, "Description for product 464", "Product 464", 1982m },
                    { 465, "Description for product 465", "Product 465", 1070m },
                    { 466, "Description for product 466", "Product 466", 650m },
                    { 467, "Description for product 467", "Product 467", 990m },
                    { 454, "Description for product 454", "Product 454", 1846m },
                    { 376, "Description for product 376", "Product 376", 408m },
                    { 375, "Description for product 375", "Product 375", 1528m },
                    { 374, "Description for product 374", "Product 374", 831m },
                    { 284, "Description for product 284", "Product 284", 1193m },
                    { 285, "Description for product 285", "Product 285", 1400m },
                    { 286, "Description for product 286", "Product 286", 1105m },
                    { 287, "Description for product 287", "Product 287", 1669m },
                    { 288, "Description for product 288", "Product 288", 1424m },
                    { 289, "Description for product 289", "Product 289", 1292m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 290, "Description for product 290", "Product 290", 121m },
                    { 291, "Description for product 291", "Product 291", 973m },
                    { 292, "Description for product 292", "Product 292", 1119m },
                    { 293, "Description for product 293", "Product 293", 534m },
                    { 294, "Description for product 294", "Product 294", 358m },
                    { 295, "Description for product 295", "Product 295", 271m },
                    { 296, "Description for product 296", "Product 296", 1358m },
                    { 297, "Description for product 297", "Product 297", 1045m },
                    { 298, "Description for product 298", "Product 298", 1149m },
                    { 299, "Description for product 299", "Product 299", 1983m },
                    { 300, "Description for product 300", "Product 300", 1126m },
                    { 301, "Description for product 301", "Product 301", 1344m },
                    { 302, "Description for product 302", "Product 302", 1484m },
                    { 303, "Description for product 303", "Product 303", 1745m },
                    { 304, "Description for product 304", "Product 304", 1195m },
                    { 305, "Description for product 305", "Product 305", 1631m },
                    { 306, "Description for product 306", "Product 306", 176m },
                    { 307, "Description for product 307", "Product 307", 1306m },
                    { 308, "Description for product 308", "Product 308", 702m },
                    { 309, "Description for product 309", "Product 309", 952m },
                    { 310, "Description for product 310", "Product 310", 615m },
                    { 283, "Description for product 283", "Product 283", 1759m },
                    { 282, "Description for product 282", "Product 282", 1303m },
                    { 281, "Description for product 281", "Product 281", 591m },
                    { 280, "Description for product 280", "Product 280", 1603m },
                    { 252, "Description for product 252", "Product 252", 1355m },
                    { 253, "Description for product 253", "Product 253", 445m },
                    { 254, "Description for product 254", "Product 254", 431m },
                    { 255, "Description for product 255", "Product 255", 1855m },
                    { 256, "Description for product 256", "Product 256", 1060m },
                    { 257, "Description for product 257", "Product 257", 1505m },
                    { 258, "Description for product 258", "Product 258", 1052m },
                    { 259, "Description for product 259", "Product 259", 1632m },
                    { 260, "Description for product 260", "Product 260", 1647m },
                    { 261, "Description for product 261", "Product 261", 679m },
                    { 262, "Description for product 262", "Product 262", 1518m },
                    { 263, "Description for product 263", "Product 263", 1458m },
                    { 264, "Description for product 264", "Product 264", 1456m },
                    { 311, "Description for product 311", "Product 311", 1624m },
                    { 265, "Description for product 265", "Product 265", 431m },
                    { 267, "Description for product 267", "Product 267", 1882m },
                    { 268, "Description for product 268", "Product 268", 1426m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 269, "Description for product 269", "Product 269", 459m },
                    { 270, "Description for product 270", "Product 270", 1538m },
                    { 271, "Description for product 271", "Product 271", 814m },
                    { 272, "Description for product 272", "Product 272", 1694m },
                    { 273, "Description for product 273", "Product 273", 148m },
                    { 274, "Description for product 274", "Product 274", 1742m },
                    { 275, "Description for product 275", "Product 275", 1478m },
                    { 276, "Description for product 276", "Product 276", 1339m },
                    { 277, "Description for product 277", "Product 277", 1436m },
                    { 278, "Description for product 278", "Product 278", 183m },
                    { 279, "Description for product 279", "Product 279", 574m },
                    { 266, "Description for product 266", "Product 266", 1044m },
                    { 999, "Description for product 999", "Product 999", 1158m },
                    { 312, "Description for product 312", "Product 312", 1422m },
                    { 314, "Description for product 314", "Product 314", 129m },
                    { 347, "Description for product 347", "Product 347", 641m },
                    { 348, "Description for product 348", "Product 348", 504m },
                    { 349, "Description for product 349", "Product 349", 1202m },
                    { 350, "Description for product 350", "Product 350", 895m },
                    { 351, "Description for product 351", "Product 351", 1600m },
                    { 352, "Description for product 352", "Product 352", 780m },
                    { 353, "Description for product 353", "Product 353", 1094m },
                    { 354, "Description for product 354", "Product 354", 757m },
                    { 355, "Description for product 355", "Product 355", 1751m },
                    { 356, "Description for product 356", "Product 356", 886m },
                    { 357, "Description for product 357", "Product 357", 1350m },
                    { 358, "Description for product 358", "Product 358", 1407m },
                    { 359, "Description for product 359", "Product 359", 630m },
                    { 360, "Description for product 360", "Product 360", 1936m },
                    { 361, "Description for product 361", "Product 361", 916m },
                    { 362, "Description for product 362", "Product 362", 1516m },
                    { 363, "Description for product 363", "Product 363", 1131m },
                    { 364, "Description for product 364", "Product 364", 832m },
                    { 365, "Description for product 365", "Product 365", 321m },
                    { 366, "Description for product 366", "Product 366", 1337m },
                    { 367, "Description for product 367", "Product 367", 1322m },
                    { 368, "Description for product 368", "Product 368", 1129m },
                    { 369, "Description for product 369", "Product 369", 1771m },
                    { 370, "Description for product 370", "Product 370", 149m },
                    { 371, "Description for product 371", "Product 371", 1818m },
                    { 372, "Description for product 372", "Product 372", 1193m },
                    { 373, "Description for product 373", "Product 373", 803m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 346, "Description for product 346", "Product 346", 1550m },
                    { 345, "Description for product 345", "Product 345", 497m },
                    { 344, "Description for product 344", "Product 344", 776m },
                    { 343, "Description for product 343", "Product 343", 571m },
                    { 315, "Description for product 315", "Product 315", 1155m },
                    { 316, "Description for product 316", "Product 316", 1376m },
                    { 317, "Description for product 317", "Product 317", 1758m },
                    { 318, "Description for product 318", "Product 318", 365m },
                    { 319, "Description for product 319", "Product 319", 155m },
                    { 320, "Description for product 320", "Product 320", 1326m },
                    { 321, "Description for product 321", "Product 321", 1375m },
                    { 322, "Description for product 322", "Product 322", 558m },
                    { 323, "Description for product 323", "Product 323", 234m },
                    { 324, "Description for product 324", "Product 324", 437m },
                    { 325, "Description for product 325", "Product 325", 665m },
                    { 326, "Description for product 326", "Product 326", 1694m },
                    { 327, "Description for product 327", "Product 327", 1259m },
                    { 313, "Description for product 313", "Product 313", 577m },
                    { 328, "Description for product 328", "Product 328", 1790m },
                    { 330, "Description for product 330", "Product 330", 220m },
                    { 331, "Description for product 331", "Product 331", 394m },
                    { 332, "Description for product 332", "Product 332", 386m },
                    { 333, "Description for product 333", "Product 333", 199m },
                    { 334, "Description for product 334", "Product 334", 1447m },
                    { 335, "Description for product 335", "Product 335", 358m },
                    { 336, "Description for product 336", "Product 336", 1106m },
                    { 337, "Description for product 337", "Product 337", 1558m },
                    { 338, "Description for product 338", "Product 338", 664m },
                    { 339, "Description for product 339", "Product 339", 1561m },
                    { 340, "Description for product 340", "Product 340", 1324m },
                    { 341, "Description for product 341", "Product 341", 1798m },
                    { 342, "Description for product 342", "Product 342", 1066m },
                    { 329, "Description for product 329", "Product 329", 1571m },
                    { 1000, "Description for product 1000", "Product 1000", 676m }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 1, 1, 18 },
                    { 659, 659, 30 },
                    { 660, 660, 18 },
                    { 661, 661, 15 },
                    { 662, 662, 39 },
                    { 663, 663, 34 },
                    { 664, 664, 22 },
                    { 665, 665, 31 },
                    { 666, 666, 19 },
                    { 667, 667, 8 },
                    { 668, 668, 46 },
                    { 669, 669, 37 },
                    { 670, 670, 27 },
                    { 671, 671, 40 },
                    { 672, 672, 13 },
                    { 673, 673, 10 },
                    { 674, 674, 47 },
                    { 675, 675, 19 },
                    { 676, 676, 40 },
                    { 677, 677, 45 },
                    { 678, 678, 40 },
                    { 679, 679, 8 },
                    { 680, 680, 37 },
                    { 681, 681, 4 },
                    { 682, 682, 40 },
                    { 683, 683, 7 },
                    { 684, 684, 18 },
                    { 685, 685, 14 },
                    { 658, 658, 39 },
                    { 686, 686, 6 },
                    { 657, 657, 43 },
                    { 655, 655, 5 },
                    { 628, 628, 40 },
                    { 629, 629, 27 },
                    { 630, 630, 30 },
                    { 631, 631, 42 },
                    { 632, 632, 41 },
                    { 633, 633, 43 },
                    { 634, 634, 43 },
                    { 635, 635, 7 },
                    { 636, 636, 13 },
                    { 637, 637, 38 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 638, 638, 21 },
                    { 639, 639, 46 },
                    { 640, 640, 29 },
                    { 641, 641, 0 },
                    { 642, 642, 4 },
                    { 643, 643, 32 },
                    { 644, 644, 33 },
                    { 645, 645, 34 },
                    { 646, 646, 10 },
                    { 647, 647, 9 },
                    { 648, 648, 18 },
                    { 649, 649, 33 },
                    { 650, 650, 9 },
                    { 651, 651, 15 },
                    { 652, 652, 35 },
                    { 653, 653, 0 },
                    { 654, 654, 37 },
                    { 656, 656, 49 },
                    { 687, 687, 40 },
                    { 688, 688, 5 },
                    { 689, 689, 37 },
                    { 722, 722, 3 },
                    { 723, 723, 8 },
                    { 724, 724, 29 },
                    { 725, 725, 7 },
                    { 726, 726, 42 },
                    { 727, 727, 22 },
                    { 728, 728, 32 },
                    { 729, 729, 33 },
                    { 730, 730, 8 },
                    { 731, 731, 20 },
                    { 732, 732, 35 },
                    { 733, 733, 37 },
                    { 734, 734, 44 },
                    { 735, 735, 35 },
                    { 736, 736, 41 },
                    { 737, 737, 10 },
                    { 738, 738, 1 },
                    { 739, 739, 49 },
                    { 740, 740, 12 },
                    { 741, 741, 31 },
                    { 742, 742, 38 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 743, 743, 37 },
                    { 744, 744, 22 },
                    { 745, 745, 4 },
                    { 746, 746, 16 },
                    { 747, 747, 17 },
                    { 748, 748, 48 },
                    { 721, 721, 28 },
                    { 720, 720, 24 },
                    { 719, 719, 7 },
                    { 718, 718, 16 },
                    { 690, 690, 7 },
                    { 691, 691, 19 },
                    { 692, 692, 48 },
                    { 693, 693, 41 },
                    { 694, 694, 27 },
                    { 695, 695, 13 },
                    { 696, 696, 10 },
                    { 697, 697, 20 },
                    { 698, 698, 10 },
                    { 699, 699, 2 },
                    { 700, 700, 14 },
                    { 701, 701, 2 },
                    { 702, 702, 12 },
                    { 627, 627, 8 },
                    { 703, 703, 30 },
                    { 705, 705, 19 },
                    { 706, 706, 2 },
                    { 707, 707, 25 },
                    { 708, 708, 2 },
                    { 709, 709, 18 },
                    { 710, 710, 14 },
                    { 711, 711, 3 },
                    { 712, 712, 3 },
                    { 713, 713, 30 },
                    { 714, 714, 42 },
                    { 715, 715, 14 },
                    { 716, 716, 24 },
                    { 717, 717, 32 },
                    { 704, 704, 6 },
                    { 749, 749, 13 },
                    { 626, 626, 13 },
                    { 624, 624, 42 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 534, 534, 17 },
                    { 535, 535, 23 },
                    { 536, 536, 17 },
                    { 537, 537, 32 },
                    { 538, 538, 43 },
                    { 539, 539, 46 },
                    { 540, 540, 37 },
                    { 541, 541, 37 },
                    { 542, 542, 28 },
                    { 543, 543, 7 },
                    { 544, 544, 8 },
                    { 545, 545, 14 },
                    { 546, 546, 41 },
                    { 547, 547, 48 },
                    { 548, 548, 20 },
                    { 549, 549, 41 },
                    { 550, 550, 43 },
                    { 551, 551, 46 },
                    { 552, 552, 45 },
                    { 553, 553, 28 },
                    { 554, 554, 33 },
                    { 555, 555, 10 },
                    { 556, 556, 29 },
                    { 557, 557, 4 },
                    { 558, 558, 34 },
                    { 559, 559, 30 },
                    { 560, 560, 22 },
                    { 533, 533, 18 },
                    { 561, 561, 49 },
                    { 532, 532, 45 },
                    { 530, 530, 49 },
                    { 503, 503, 43 },
                    { 504, 504, 7 },
                    { 505, 505, 2 },
                    { 506, 506, 40 },
                    { 507, 507, 29 },
                    { 508, 508, 7 },
                    { 509, 509, 29 },
                    { 510, 510, 26 },
                    { 511, 511, 8 },
                    { 512, 512, 32 },
                    { 513, 513, 49 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 514, 514, 11 },
                    { 515, 515, 30 },
                    { 516, 516, 44 },
                    { 517, 517, 15 },
                    { 518, 518, 11 },
                    { 519, 519, 3 },
                    { 520, 520, 19 },
                    { 521, 521, 14 },
                    { 522, 522, 25 },
                    { 523, 523, 9 },
                    { 524, 524, 9 },
                    { 525, 525, 26 },
                    { 526, 526, 30 },
                    { 527, 527, 40 },
                    { 528, 528, 42 },
                    { 529, 529, 21 },
                    { 531, 531, 25 },
                    { 562, 562, 36 },
                    { 563, 563, 35 },
                    { 564, 564, 30 },
                    { 597, 597, 42 },
                    { 598, 598, 27 },
                    { 599, 599, 7 },
                    { 600, 600, 1 },
                    { 601, 601, 27 },
                    { 602, 602, 17 },
                    { 603, 603, 32 },
                    { 604, 604, 29 },
                    { 605, 605, 31 },
                    { 606, 606, 24 },
                    { 607, 607, 30 },
                    { 608, 608, 12 },
                    { 609, 609, 2 },
                    { 610, 610, 24 },
                    { 611, 611, 10 },
                    { 612, 612, 2 },
                    { 613, 613, 39 },
                    { 614, 614, 45 },
                    { 615, 615, 41 },
                    { 616, 616, 28 },
                    { 617, 617, 35 },
                    { 618, 618, 6 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 619, 619, 26 },
                    { 620, 620, 19 },
                    { 621, 621, 45 },
                    { 622, 622, 28 },
                    { 623, 623, 23 },
                    { 596, 596, 1 },
                    { 595, 595, 38 },
                    { 594, 594, 24 },
                    { 593, 593, 13 },
                    { 565, 565, 0 },
                    { 566, 566, 12 },
                    { 567, 567, 13 },
                    { 568, 568, 31 },
                    { 569, 569, 37 },
                    { 570, 570, 12 },
                    { 571, 571, 11 },
                    { 572, 572, 22 },
                    { 573, 573, 14 },
                    { 574, 574, 16 },
                    { 575, 575, 31 },
                    { 576, 576, 35 },
                    { 577, 577, 18 },
                    { 625, 625, 48 },
                    { 578, 578, 1 },
                    { 580, 580, 35 },
                    { 581, 581, 31 },
                    { 582, 582, 20 },
                    { 583, 583, 1 },
                    { 584, 584, 28 },
                    { 585, 585, 3 },
                    { 586, 586, 30 },
                    { 587, 587, 17 },
                    { 588, 588, 34 },
                    { 589, 589, 7 },
                    { 590, 590, 44 },
                    { 591, 591, 13 },
                    { 592, 592, 48 },
                    { 579, 579, 44 },
                    { 502, 502, 14 },
                    { 750, 750, 39 },
                    { 752, 752, 3 },
                    { 909, 909, 4 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 910, 910, 40 },
                    { 911, 911, 12 },
                    { 912, 912, 35 },
                    { 913, 913, 4 },
                    { 914, 914, 36 },
                    { 915, 915, 48 },
                    { 916, 916, 32 },
                    { 917, 917, 16 },
                    { 918, 918, 4 },
                    { 919, 919, 38 },
                    { 920, 920, 0 },
                    { 921, 921, 2 },
                    { 922, 922, 2 },
                    { 923, 923, 46 },
                    { 924, 924, 18 },
                    { 925, 925, 16 },
                    { 926, 926, 13 },
                    { 927, 927, 18 },
                    { 928, 928, 2 },
                    { 929, 929, 27 },
                    { 930, 930, 7 },
                    { 931, 931, 27 },
                    { 932, 932, 35 },
                    { 933, 933, 30 },
                    { 934, 934, 6 },
                    { 935, 935, 7 },
                    { 908, 908, 2 },
                    { 936, 936, 21 },
                    { 907, 907, 42 },
                    { 905, 905, 0 },
                    { 878, 878, 16 },
                    { 879, 879, 16 },
                    { 880, 880, 17 },
                    { 881, 881, 20 },
                    { 882, 882, 34 },
                    { 883, 883, 24 },
                    { 884, 884, 38 },
                    { 885, 885, 41 },
                    { 886, 886, 24 },
                    { 887, 887, 41 },
                    { 888, 888, 7 },
                    { 889, 889, 38 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 890, 890, 47 },
                    { 891, 891, 41 },
                    { 892, 892, 11 },
                    { 893, 893, 25 },
                    { 894, 894, 1 },
                    { 895, 895, 17 },
                    { 896, 896, 38 },
                    { 897, 897, 32 },
                    { 898, 898, 45 },
                    { 899, 899, 36 },
                    { 900, 900, 9 },
                    { 901, 901, 9 },
                    { 902, 902, 48 },
                    { 903, 903, 28 },
                    { 904, 904, 12 },
                    { 906, 906, 19 },
                    { 937, 937, 5 },
                    { 938, 938, 12 },
                    { 939, 939, 38 },
                    { 972, 972, 4 },
                    { 973, 973, 16 },
                    { 974, 974, 16 },
                    { 975, 975, 17 },
                    { 976, 976, 13 },
                    { 977, 977, 49 },
                    { 978, 978, 47 },
                    { 979, 979, 34 },
                    { 980, 980, 9 },
                    { 981, 981, 6 },
                    { 982, 982, 29 },
                    { 983, 983, 0 },
                    { 984, 984, 42 },
                    { 985, 985, 35 },
                    { 986, 986, 48 },
                    { 987, 987, 28 },
                    { 988, 988, 44 },
                    { 989, 989, 49 },
                    { 990, 990, 49 },
                    { 991, 991, 19 },
                    { 992, 992, 45 },
                    { 993, 993, 16 },
                    { 994, 994, 1 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 995, 995, 21 },
                    { 996, 996, 42 },
                    { 997, 997, 14 },
                    { 998, 998, 6 },
                    { 971, 971, 27 },
                    { 970, 970, 27 },
                    { 969, 969, 29 },
                    { 968, 968, 47 },
                    { 940, 940, 21 },
                    { 941, 941, 32 },
                    { 942, 942, 39 },
                    { 943, 943, 3 },
                    { 944, 944, 48 },
                    { 945, 945, 34 },
                    { 946, 946, 6 },
                    { 947, 947, 6 },
                    { 948, 948, 39 },
                    { 949, 949, 2 },
                    { 950, 950, 34 },
                    { 951, 951, 22 },
                    { 952, 952, 28 },
                    { 877, 877, 30 },
                    { 953, 953, 7 },
                    { 955, 955, 7 },
                    { 956, 956, 7 },
                    { 957, 957, 2 },
                    { 958, 958, 10 },
                    { 959, 959, 46 },
                    { 960, 960, 36 },
                    { 961, 961, 0 },
                    { 962, 962, 39 },
                    { 963, 963, 24 },
                    { 964, 964, 46 },
                    { 965, 965, 12 },
                    { 966, 966, 27 },
                    { 967, 967, 4 },
                    { 954, 954, 36 },
                    { 751, 751, 27 },
                    { 876, 876, 10 },
                    { 874, 874, 45 },
                    { 784, 784, 44 },
                    { 785, 785, 30 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 786, 786, 16 },
                    { 787, 787, 32 },
                    { 788, 788, 9 },
                    { 789, 789, 7 },
                    { 790, 790, 36 },
                    { 791, 791, 37 },
                    { 792, 792, 9 },
                    { 793, 793, 2 },
                    { 794, 794, 22 },
                    { 795, 795, 31 },
                    { 796, 796, 38 },
                    { 797, 797, 19 },
                    { 798, 798, 26 },
                    { 799, 799, 28 },
                    { 800, 800, 36 },
                    { 801, 801, 0 },
                    { 802, 802, 30 },
                    { 803, 803, 41 },
                    { 804, 804, 39 },
                    { 805, 805, 24 },
                    { 806, 806, 46 },
                    { 807, 807, 36 },
                    { 808, 808, 6 },
                    { 809, 809, 34 },
                    { 810, 810, 46 },
                    { 783, 783, 19 },
                    { 811, 811, 32 },
                    { 782, 782, 23 },
                    { 780, 780, 41 },
                    { 753, 753, 2 },
                    { 754, 754, 27 },
                    { 755, 755, 36 },
                    { 756, 756, 48 },
                    { 757, 757, 4 },
                    { 758, 758, 0 },
                    { 759, 759, 48 },
                    { 760, 760, 26 },
                    { 761, 761, 30 },
                    { 762, 762, 43 },
                    { 763, 763, 18 },
                    { 764, 764, 10 },
                    { 765, 765, 44 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 766, 766, 18 },
                    { 767, 767, 16 },
                    { 768, 768, 36 },
                    { 769, 769, 7 },
                    { 770, 770, 23 },
                    { 771, 771, 14 },
                    { 772, 772, 31 },
                    { 773, 773, 17 },
                    { 774, 774, 45 },
                    { 775, 775, 43 },
                    { 776, 776, 40 },
                    { 777, 777, 16 },
                    { 778, 778, 36 },
                    { 779, 779, 25 },
                    { 781, 781, 24 },
                    { 812, 812, 17 },
                    { 813, 813, 24 },
                    { 814, 814, 7 },
                    { 847, 847, 34 },
                    { 848, 848, 45 },
                    { 849, 849, 20 },
                    { 850, 850, 25 },
                    { 851, 851, 13 },
                    { 852, 852, 45 },
                    { 853, 853, 47 },
                    { 854, 854, 0 },
                    { 855, 855, 0 },
                    { 856, 856, 43 },
                    { 857, 857, 2 },
                    { 858, 858, 20 },
                    { 859, 859, 3 },
                    { 860, 860, 19 },
                    { 861, 861, 16 },
                    { 862, 862, 41 },
                    { 863, 863, 42 },
                    { 864, 864, 29 },
                    { 865, 865, 25 },
                    { 866, 866, 43 },
                    { 867, 867, 9 },
                    { 868, 868, 35 },
                    { 869, 869, 16 },
                    { 870, 870, 8 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 871, 871, 24 },
                    { 872, 872, 44 },
                    { 873, 873, 3 },
                    { 846, 846, 19 },
                    { 845, 845, 3 },
                    { 844, 844, 11 },
                    { 843, 843, 25 },
                    { 815, 815, 1 },
                    { 816, 816, 6 },
                    { 817, 817, 24 },
                    { 818, 818, 23 },
                    { 819, 819, 29 },
                    { 820, 820, 27 },
                    { 821, 821, 35 },
                    { 822, 822, 6 },
                    { 823, 823, 28 },
                    { 824, 824, 20 },
                    { 825, 825, 36 },
                    { 826, 826, 5 },
                    { 827, 827, 29 },
                    { 875, 875, 46 },
                    { 828, 828, 45 },
                    { 830, 830, 5 },
                    { 831, 831, 20 },
                    { 832, 832, 39 },
                    { 833, 833, 8 },
                    { 834, 834, 39 },
                    { 835, 835, 41 },
                    { 836, 836, 43 },
                    { 837, 837, 31 },
                    { 838, 838, 29 },
                    { 839, 839, 20 },
                    { 840, 840, 34 },
                    { 841, 841, 30 },
                    { 842, 842, 25 },
                    { 829, 829, 13 },
                    { 501, 501, 4 },
                    { 500, 500, 24 },
                    { 499, 499, 2 },
                    { 158, 158, 49 },
                    { 159, 159, 24 },
                    { 160, 160, 5 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 161, 161, 23 },
                    { 162, 162, 14 },
                    { 163, 163, 43 },
                    { 164, 164, 9 },
                    { 165, 165, 39 },
                    { 166, 166, 13 },
                    { 167, 167, 30 },
                    { 168, 168, 41 },
                    { 169, 169, 27 },
                    { 170, 170, 2 },
                    { 171, 171, 46 },
                    { 172, 172, 34 },
                    { 173, 173, 3 },
                    { 174, 174, 25 },
                    { 175, 175, 4 },
                    { 176, 176, 21 },
                    { 177, 177, 8 },
                    { 178, 178, 1 },
                    { 179, 179, 34 },
                    { 180, 180, 19 },
                    { 181, 181, 20 },
                    { 182, 182, 34 },
                    { 183, 183, 40 },
                    { 184, 184, 7 },
                    { 157, 157, 13 },
                    { 185, 185, 16 },
                    { 156, 156, 41 },
                    { 154, 154, 44 },
                    { 127, 127, 49 },
                    { 128, 128, 4 },
                    { 129, 129, 35 },
                    { 130, 130, 21 },
                    { 131, 131, 11 },
                    { 132, 132, 24 },
                    { 133, 133, 9 },
                    { 134, 134, 37 },
                    { 135, 135, 36 },
                    { 136, 136, 33 },
                    { 137, 137, 29 },
                    { 138, 138, 17 },
                    { 139, 139, 7 },
                    { 140, 140, 22 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 141, 141, 43 },
                    { 142, 142, 41 },
                    { 143, 143, 12 },
                    { 144, 144, 25 },
                    { 145, 145, 11 },
                    { 146, 146, 19 },
                    { 147, 147, 13 },
                    { 148, 148, 15 },
                    { 149, 149, 13 },
                    { 150, 150, 28 },
                    { 151, 151, 4 },
                    { 152, 152, 14 },
                    { 153, 153, 14 },
                    { 155, 155, 10 },
                    { 186, 186, 46 },
                    { 187, 187, 10 },
                    { 188, 188, 15 },
                    { 221, 221, 2 },
                    { 222, 222, 14 },
                    { 223, 223, 14 },
                    { 224, 224, 33 },
                    { 225, 225, 32 },
                    { 226, 226, 15 },
                    { 227, 227, 41 },
                    { 228, 228, 1 },
                    { 229, 229, 27 },
                    { 230, 230, 25 },
                    { 231, 231, 23 },
                    { 232, 232, 5 },
                    { 233, 233, 15 },
                    { 234, 234, 36 },
                    { 235, 235, 29 },
                    { 236, 236, 47 },
                    { 237, 237, 47 },
                    { 238, 238, 29 },
                    { 239, 239, 25 },
                    { 240, 240, 46 },
                    { 241, 241, 35 },
                    { 242, 242, 21 },
                    { 243, 243, 25 },
                    { 244, 244, 37 },
                    { 245, 245, 11 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 246, 246, 8 },
                    { 247, 247, 16 },
                    { 220, 220, 43 },
                    { 219, 219, 42 },
                    { 218, 218, 35 },
                    { 217, 217, 24 },
                    { 189, 189, 26 },
                    { 190, 190, 44 },
                    { 191, 191, 19 },
                    { 192, 192, 30 },
                    { 193, 193, 43 },
                    { 194, 194, 2 },
                    { 195, 195, 48 },
                    { 196, 196, 28 },
                    { 197, 197, 48 },
                    { 198, 198, 3 },
                    { 199, 199, 36 },
                    { 200, 200, 48 },
                    { 201, 201, 39 },
                    { 126, 126, 33 },
                    { 202, 202, 22 },
                    { 204, 204, 11 },
                    { 205, 205, 32 },
                    { 206, 206, 20 },
                    { 207, 207, 11 },
                    { 208, 208, 38 },
                    { 209, 209, 39 },
                    { 210, 210, 38 },
                    { 211, 211, 32 },
                    { 212, 212, 11 },
                    { 213, 213, 14 },
                    { 214, 214, 4 },
                    { 215, 215, 34 },
                    { 216, 216, 39 },
                    { 203, 203, 37 },
                    { 248, 248, 38 },
                    { 125, 125, 39 },
                    { 123, 123, 27 },
                    { 33, 33, 2 },
                    { 34, 34, 14 },
                    { 35, 35, 24 },
                    { 36, 36, 1 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 37, 37, 30 },
                    { 38, 38, 44 },
                    { 39, 39, 11 },
                    { 40, 40, 4 },
                    { 41, 41, 39 },
                    { 42, 42, 34 },
                    { 43, 43, 6 },
                    { 44, 44, 2 },
                    { 45, 45, 8 },
                    { 46, 46, 28 },
                    { 47, 47, 45 },
                    { 48, 48, 40 },
                    { 49, 49, 12 },
                    { 50, 50, 13 },
                    { 51, 51, 3 },
                    { 52, 52, 23 },
                    { 53, 53, 19 },
                    { 54, 54, 8 },
                    { 55, 55, 38 },
                    { 56, 56, 24 },
                    { 57, 57, 41 },
                    { 58, 58, 38 },
                    { 59, 59, 14 },
                    { 32, 32, 40 },
                    { 60, 60, 11 },
                    { 31, 31, 35 },
                    { 29, 29, 10 },
                    { 2, 2, 46 },
                    { 3, 3, 7 },
                    { 4, 4, 42 },
                    { 5, 5, 32 },
                    { 6, 6, 16 },
                    { 7, 7, 25 },
                    { 8, 8, 18 },
                    { 9, 9, 43 },
                    { 10, 10, 46 },
                    { 11, 11, 24 },
                    { 12, 12, 17 },
                    { 13, 13, 18 },
                    { 14, 14, 19 },
                    { 15, 15, 0 },
                    { 16, 16, 5 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 17, 17, 24 },
                    { 18, 18, 16 },
                    { 19, 19, 44 },
                    { 20, 20, 17 },
                    { 21, 21, 22 },
                    { 22, 22, 43 },
                    { 23, 23, 4 },
                    { 24, 24, 18 },
                    { 25, 25, 28 },
                    { 26, 26, 20 },
                    { 27, 27, 16 },
                    { 28, 28, 42 },
                    { 30, 30, 49 },
                    { 61, 61, 0 },
                    { 62, 62, 32 },
                    { 63, 63, 8 },
                    { 96, 96, 6 },
                    { 97, 97, 26 },
                    { 98, 98, 12 },
                    { 99, 99, 42 },
                    { 100, 100, 23 },
                    { 101, 101, 13 },
                    { 102, 102, 41 },
                    { 103, 103, 45 },
                    { 104, 104, 13 },
                    { 105, 105, 38 },
                    { 106, 106, 23 },
                    { 107, 107, 19 },
                    { 108, 108, 29 },
                    { 109, 109, 30 },
                    { 110, 110, 0 },
                    { 111, 111, 37 },
                    { 112, 112, 39 },
                    { 113, 113, 28 },
                    { 114, 114, 14 },
                    { 115, 115, 36 },
                    { 116, 116, 25 },
                    { 117, 117, 2 },
                    { 118, 118, 11 },
                    { 119, 119, 48 },
                    { 120, 120, 47 },
                    { 121, 121, 13 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 122, 122, 21 },
                    { 95, 95, 3 },
                    { 94, 94, 0 },
                    { 93, 93, 30 },
                    { 92, 92, 41 },
                    { 64, 64, 44 },
                    { 65, 65, 10 },
                    { 66, 66, 34 },
                    { 67, 67, 14 },
                    { 68, 68, 3 },
                    { 69, 69, 45 },
                    { 70, 70, 49 },
                    { 71, 71, 25 },
                    { 72, 72, 29 },
                    { 73, 73, 4 },
                    { 74, 74, 39 },
                    { 75, 75, 28 },
                    { 76, 76, 37 },
                    { 124, 124, 46 },
                    { 77, 77, 37 },
                    { 79, 79, 10 },
                    { 80, 80, 49 },
                    { 81, 81, 25 },
                    { 82, 82, 25 },
                    { 83, 83, 30 },
                    { 84, 84, 46 },
                    { 85, 85, 46 },
                    { 86, 86, 12 },
                    { 87, 87, 21 },
                    { 88, 88, 43 },
                    { 89, 89, 26 },
                    { 90, 90, 49 },
                    { 91, 91, 9 },
                    { 78, 78, 2 },
                    { 249, 249, 17 },
                    { 250, 250, 9 },
                    { 251, 251, 3 },
                    { 409, 409, 21 },
                    { 410, 410, 47 },
                    { 411, 411, 1 },
                    { 412, 412, 41 },
                    { 413, 413, 38 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 414, 414, 43 },
                    { 415, 415, 26 },
                    { 416, 416, 17 },
                    { 417, 417, 43 },
                    { 418, 418, 49 },
                    { 419, 419, 18 },
                    { 420, 420, 40 },
                    { 421, 421, 0 },
                    { 422, 422, 42 },
                    { 423, 423, 10 },
                    { 424, 424, 15 },
                    { 425, 425, 46 },
                    { 426, 426, 40 },
                    { 427, 427, 3 },
                    { 428, 428, 8 },
                    { 429, 429, 29 },
                    { 430, 430, 40 },
                    { 431, 431, 10 },
                    { 432, 432, 1 },
                    { 433, 433, 28 },
                    { 434, 434, 43 },
                    { 435, 435, 10 },
                    { 408, 408, 40 },
                    { 436, 436, 26 },
                    { 407, 407, 24 },
                    { 405, 405, 3 },
                    { 378, 378, 10 },
                    { 379, 379, 3 },
                    { 380, 380, 39 },
                    { 381, 381, 40 },
                    { 382, 382, 46 },
                    { 383, 383, 8 },
                    { 384, 384, 37 },
                    { 385, 385, 34 },
                    { 386, 386, 3 },
                    { 387, 387, 8 },
                    { 388, 388, 35 },
                    { 389, 389, 36 },
                    { 390, 390, 24 },
                    { 391, 391, 9 },
                    { 392, 392, 47 },
                    { 393, 393, 19 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 394, 394, 34 },
                    { 395, 395, 48 },
                    { 396, 396, 6 },
                    { 397, 397, 42 },
                    { 398, 398, 34 },
                    { 399, 399, 31 },
                    { 400, 400, 9 },
                    { 401, 401, 29 },
                    { 402, 402, 13 },
                    { 403, 403, 6 },
                    { 404, 404, 36 },
                    { 406, 406, 25 },
                    { 437, 437, 39 },
                    { 438, 438, 21 },
                    { 439, 439, 34 },
                    { 472, 472, 22 },
                    { 473, 473, 14 },
                    { 474, 474, 9 },
                    { 475, 475, 11 },
                    { 476, 476, 32 },
                    { 477, 477, 28 },
                    { 478, 478, 21 },
                    { 479, 479, 41 },
                    { 480, 480, 28 },
                    { 481, 481, 32 },
                    { 482, 482, 26 },
                    { 483, 483, 0 },
                    { 484, 484, 49 },
                    { 485, 485, 27 },
                    { 486, 486, 17 },
                    { 487, 487, 35 },
                    { 488, 488, 37 },
                    { 489, 489, 34 },
                    { 490, 490, 23 },
                    { 491, 491, 23 },
                    { 492, 492, 48 },
                    { 493, 493, 31 },
                    { 494, 494, 21 },
                    { 495, 495, 37 },
                    { 496, 496, 12 },
                    { 497, 497, 6 },
                    { 498, 498, 32 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 471, 471, 28 },
                    { 470, 470, 0 },
                    { 469, 469, 32 },
                    { 468, 468, 44 },
                    { 440, 440, 9 },
                    { 441, 441, 28 },
                    { 442, 442, 17 },
                    { 443, 443, 14 },
                    { 444, 444, 38 },
                    { 445, 445, 23 },
                    { 446, 446, 17 },
                    { 447, 447, 8 },
                    { 448, 448, 26 },
                    { 449, 449, 7 },
                    { 450, 450, 30 },
                    { 451, 451, 12 },
                    { 452, 452, 43 },
                    { 377, 377, 36 },
                    { 453, 453, 16 },
                    { 455, 455, 9 },
                    { 456, 456, 37 },
                    { 457, 457, 3 },
                    { 458, 458, 41 },
                    { 459, 459, 40 },
                    { 460, 460, 12 },
                    { 461, 461, 21 },
                    { 462, 462, 16 },
                    { 463, 463, 10 },
                    { 464, 464, 31 },
                    { 465, 465, 36 },
                    { 466, 466, 49 },
                    { 467, 467, 12 },
                    { 454, 454, 41 },
                    { 376, 376, 3 },
                    { 375, 375, 46 },
                    { 374, 374, 28 },
                    { 284, 284, 18 },
                    { 285, 285, 21 },
                    { 286, 286, 10 },
                    { 287, 287, 44 },
                    { 288, 288, 22 },
                    { 289, 289, 41 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 290, 290, 4 },
                    { 291, 291, 39 },
                    { 292, 292, 42 },
                    { 293, 293, 1 },
                    { 294, 294, 9 },
                    { 295, 295, 17 },
                    { 296, 296, 25 },
                    { 297, 297, 10 },
                    { 298, 298, 11 },
                    { 299, 299, 22 },
                    { 300, 300, 34 },
                    { 301, 301, 11 },
                    { 302, 302, 38 },
                    { 303, 303, 13 },
                    { 304, 304, 30 },
                    { 305, 305, 16 },
                    { 306, 306, 8 },
                    { 307, 307, 2 },
                    { 308, 308, 14 },
                    { 309, 309, 35 },
                    { 310, 310, 14 },
                    { 283, 283, 33 },
                    { 282, 282, 2 },
                    { 281, 281, 49 },
                    { 280, 280, 24 },
                    { 252, 252, 12 },
                    { 253, 253, 10 },
                    { 254, 254, 43 },
                    { 255, 255, 45 },
                    { 256, 256, 25 },
                    { 257, 257, 8 },
                    { 258, 258, 4 },
                    { 259, 259, 28 },
                    { 260, 260, 16 },
                    { 261, 261, 29 },
                    { 262, 262, 9 },
                    { 263, 263, 11 },
                    { 264, 264, 14 },
                    { 311, 311, 36 },
                    { 265, 265, 15 },
                    { 267, 267, 46 },
                    { 268, 268, 27 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 269, 269, 25 },
                    { 270, 270, 37 },
                    { 271, 271, 42 },
                    { 272, 272, 45 },
                    { 273, 273, 9 },
                    { 274, 274, 45 },
                    { 275, 275, 7 },
                    { 276, 276, 30 },
                    { 277, 277, 39 },
                    { 278, 278, 26 },
                    { 279, 279, 21 },
                    { 266, 266, 27 },
                    { 999, 999, 36 },
                    { 312, 312, 31 },
                    { 314, 314, 3 },
                    { 347, 347, 9 },
                    { 348, 348, 47 },
                    { 349, 349, 42 },
                    { 350, 350, 40 },
                    { 351, 351, 48 },
                    { 352, 352, 16 },
                    { 353, 353, 19 },
                    { 354, 354, 17 },
                    { 355, 355, 0 },
                    { 356, 356, 37 },
                    { 357, 357, 1 },
                    { 358, 358, 41 },
                    { 359, 359, 32 },
                    { 360, 360, 17 },
                    { 361, 361, 14 },
                    { 362, 362, 2 },
                    { 363, 363, 36 },
                    { 364, 364, 2 },
                    { 365, 365, 44 },
                    { 366, 366, 8 },
                    { 367, 367, 28 },
                    { 368, 368, 46 },
                    { 369, 369, 40 },
                    { 370, 370, 5 },
                    { 371, 371, 37 },
                    { 372, 372, 23 },
                    { 373, 373, 42 }
                });

            migrationBuilder.InsertData(
                schema: "Catalog",
                table: "Stocks",
                columns: new[] { "ProductInStockId", "ProductId", "Stock" },
                values: new object[,]
                {
                    { 346, 346, 7 },
                    { 345, 345, 17 },
                    { 344, 344, 26 },
                    { 343, 343, 37 },
                    { 315, 315, 16 },
                    { 316, 316, 26 },
                    { 317, 317, 26 },
                    { 318, 318, 43 },
                    { 319, 319, 42 },
                    { 320, 320, 4 },
                    { 321, 321, 33 },
                    { 322, 322, 23 },
                    { 323, 323, 36 },
                    { 324, 324, 21 },
                    { 325, 325, 47 },
                    { 326, 326, 49 },
                    { 327, 327, 44 },
                    { 313, 313, 33 },
                    { 328, 328, 0 },
                    { 330, 330, 32 },
                    { 331, 331, 20 },
                    { 332, 332, 27 },
                    { 333, 333, 3 },
                    { 334, 334, 36 },
                    { 335, 335, 12 },
                    { 336, 336, 11 },
                    { 337, 337, 39 },
                    { 338, 338, 2 },
                    { 339, 339, 1 },
                    { 340, 340, 13 },
                    { 341, 341, 8 },
                    { 342, 342, 29 },
                    { 329, 329, 28 },
                    { 1000, 1000, 6 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 10);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 11);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 12);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 13);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 14);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 15);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 16);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 17);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 18);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 19);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 20);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 21);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 22);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 23);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 24);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 25);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 26);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 27);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 28);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 29);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 30);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 31);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 32);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 33);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 34);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 35);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 36);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 37);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 38);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 39);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 40);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 41);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 42);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 43);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 44);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 45);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 46);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 47);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 48);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 49);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 50);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 51);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 52);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 53);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 54);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 55);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 56);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 57);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 58);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 59);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 60);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 61);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 62);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 63);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 64);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 65);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 66);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 67);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 68);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 69);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 70);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 71);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 72);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 73);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 74);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 75);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 76);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 77);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 78);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 79);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 80);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 81);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 82);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 83);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 84);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 85);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 86);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 87);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 88);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 89);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 90);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 91);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 92);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 93);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 94);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 95);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 96);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 97);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 98);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 99);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 100);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 101);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 102);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 103);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 104);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 105);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 106);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 107);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 108);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 109);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 110);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 111);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 112);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 113);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 114);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 115);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 116);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 117);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 118);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 119);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 120);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 121);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 122);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 123);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 124);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 125);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 126);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 127);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 128);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 129);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 130);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 131);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 132);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 133);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 134);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 135);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 136);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 137);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 138);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 139);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 140);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 141);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 142);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 143);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 144);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 145);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 146);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 147);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 148);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 149);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 150);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 151);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 152);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 153);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 154);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 155);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 156);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 157);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 158);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 159);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 160);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 161);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 162);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 163);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 164);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 165);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 166);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 167);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 168);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 169);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 170);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 171);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 172);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 173);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 174);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 175);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 176);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 177);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 178);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 179);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 180);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 181);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 182);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 183);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 184);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 185);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 186);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 187);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 188);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 189);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 190);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 191);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 192);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 193);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 194);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 195);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 196);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 197);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 198);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 199);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 200);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 201);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 202);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 203);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 204);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 205);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 206);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 207);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 208);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 209);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 210);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 211);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 212);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 213);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 214);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 215);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 216);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 217);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 218);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 219);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 220);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 221);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 222);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 223);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 224);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 225);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 226);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 227);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 228);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 229);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 230);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 231);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 232);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 233);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 234);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 235);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 236);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 237);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 238);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 239);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 240);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 241);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 242);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 243);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 244);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 245);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 246);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 247);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 248);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 249);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 250);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 251);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 252);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 253);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 254);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 255);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 256);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 257);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 258);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 259);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 260);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 261);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 262);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 263);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 264);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 265);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 266);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 267);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 268);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 269);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 270);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 271);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 272);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 273);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 274);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 275);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 276);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 277);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 278);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 279);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 280);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 281);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 282);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 283);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 284);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 285);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 286);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 287);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 288);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 289);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 290);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 291);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 292);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 293);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 294);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 295);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 296);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 297);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 298);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 299);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 300);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 301);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 302);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 303);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 304);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 305);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 306);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 307);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 308);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 309);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 310);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 311);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 312);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 313);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 314);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 315);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 316);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 317);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 318);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 319);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 320);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 321);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 322);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 323);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 324);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 325);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 326);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 327);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 328);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 329);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 330);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 331);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 332);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 333);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 334);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 335);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 336);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 337);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 338);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 339);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 340);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 341);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 342);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 343);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 344);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 345);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 346);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 347);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 348);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 349);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 350);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 351);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 352);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 353);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 354);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 355);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 356);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 357);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 358);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 359);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 360);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 361);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 362);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 363);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 364);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 365);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 366);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 367);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 368);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 369);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 370);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 371);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 372);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 373);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 374);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 375);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 376);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 377);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 378);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 379);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 380);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 381);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 382);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 383);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 384);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 385);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 386);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 387);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 388);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 389);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 390);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 391);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 392);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 393);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 394);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 395);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 396);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 397);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 398);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 399);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 400);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 401);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 402);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 403);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 404);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 405);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 406);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 407);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 408);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 409);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 410);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 411);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 412);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 413);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 414);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 415);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 416);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 417);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 418);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 419);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 420);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 421);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 422);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 423);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 424);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 425);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 426);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 427);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 428);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 429);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 430);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 431);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 432);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 433);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 434);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 435);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 436);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 437);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 438);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 439);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 440);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 441);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 442);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 443);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 444);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 445);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 446);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 447);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 448);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 449);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 450);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 451);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 452);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 453);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 454);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 455);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 456);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 457);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 458);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 459);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 460);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 461);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 462);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 463);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 464);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 465);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 466);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 467);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 468);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 469);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 470);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 471);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 472);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 473);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 474);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 475);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 476);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 477);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 478);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 479);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 480);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 481);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 482);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 483);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 484);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 485);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 486);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 487);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 488);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 489);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 490);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 491);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 492);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 493);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 494);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 495);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 496);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 497);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 498);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 499);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 500);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 501);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 502);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 503);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 504);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 505);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 506);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 507);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 508);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 509);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 510);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 511);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 512);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 513);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 514);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 515);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 516);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 517);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 518);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 519);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 520);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 521);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 522);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 523);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 524);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 525);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 526);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 527);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 528);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 529);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 530);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 531);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 532);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 533);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 534);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 535);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 536);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 537);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 538);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 539);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 540);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 541);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 542);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 543);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 544);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 545);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 546);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 547);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 548);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 549);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 550);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 551);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 552);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 553);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 554);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 555);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 556);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 557);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 558);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 559);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 560);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 561);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 562);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 563);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 564);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 565);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 566);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 567);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 568);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 569);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 570);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 571);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 572);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 573);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 574);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 575);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 576);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 577);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 578);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 579);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 580);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 581);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 582);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 583);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 584);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 585);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 586);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 587);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 588);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 589);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 590);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 591);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 592);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 593);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 594);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 595);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 596);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 597);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 598);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 599);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 600);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 601);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 602);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 603);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 604);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 605);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 606);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 607);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 608);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 609);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 610);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 611);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 612);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 613);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 614);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 615);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 616);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 617);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 618);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 619);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 620);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 621);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 622);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 623);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 624);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 625);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 626);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 627);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 628);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 629);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 630);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 631);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 632);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 633);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 634);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 635);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 636);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 637);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 638);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 639);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 640);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 641);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 642);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 643);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 644);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 645);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 646);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 647);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 648);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 649);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 650);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 651);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 652);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 653);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 654);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 655);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 656);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 657);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 658);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 659);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 660);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 661);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 662);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 663);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 664);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 665);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 666);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 667);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 668);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 669);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 670);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 671);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 672);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 673);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 674);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 675);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 676);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 677);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 678);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 679);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 680);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 681);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 682);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 683);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 684);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 685);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 686);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 687);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 688);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 689);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 690);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 691);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 692);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 693);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 694);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 695);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 696);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 697);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 698);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 699);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 700);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 701);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 702);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 703);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 704);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 705);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 706);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 707);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 708);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 709);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 710);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 711);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 712);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 713);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 714);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 715);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 716);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 717);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 718);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 719);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 720);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 721);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 722);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 723);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 724);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 725);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 726);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 727);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 728);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 729);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 730);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 731);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 732);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 733);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 734);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 735);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 736);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 737);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 738);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 739);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 740);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 741);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 742);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 743);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 744);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 745);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 746);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 747);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 748);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 749);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 750);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 751);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 752);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 753);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 754);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 755);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 756);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 757);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 758);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 759);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 760);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 761);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 762);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 763);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 764);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 765);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 766);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 767);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 768);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 769);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 770);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 771);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 772);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 773);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 774);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 775);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 776);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 777);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 778);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 779);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 780);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 781);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 782);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 783);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 784);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 785);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 786);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 787);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 788);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 789);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 790);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 791);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 792);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 793);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 794);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 795);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 796);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 797);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 798);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 799);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 800);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 801);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 802);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 803);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 804);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 805);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 806);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 807);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 808);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 809);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 810);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 811);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 812);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 813);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 814);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 815);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 816);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 817);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 818);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 819);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 820);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 821);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 822);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 823);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 824);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 825);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 826);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 827);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 828);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 829);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 830);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 831);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 832);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 833);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 834);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 835);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 836);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 837);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 838);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 839);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 840);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 841);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 842);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 843);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 844);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 845);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 846);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 847);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 848);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 849);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 850);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 851);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 852);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 853);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 854);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 855);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 856);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 857);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 858);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 859);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 860);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 861);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 862);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 863);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 864);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 865);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 866);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 867);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 868);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 869);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 870);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 871);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 872);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 873);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 874);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 875);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 876);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 877);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 878);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 879);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 880);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 881);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 882);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 883);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 884);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 885);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 886);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 887);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 888);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 889);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 890);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 891);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 892);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 893);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 894);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 895);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 896);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 897);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 898);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 899);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 900);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 901);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 902);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 903);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 904);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 905);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 906);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 907);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 908);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 909);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 910);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 911);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 912);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 913);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 914);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 915);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 916);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 917);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 918);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 919);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 920);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 921);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 922);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 923);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 924);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 925);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 926);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 927);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 928);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 929);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 930);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 931);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 932);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 933);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 934);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 935);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 936);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 937);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 938);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 939);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 940);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 941);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 942);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 943);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 944);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 945);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 946);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 947);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 948);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 949);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 950);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 951);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 952);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 953);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 954);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 955);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 956);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 957);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 958);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 959);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 960);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 961);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 962);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 963);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 964);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 965);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 966);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 967);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 968);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 969);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 970);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 971);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 972);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 973);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 974);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 975);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 976);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 977);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 978);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 979);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 980);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 981);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 982);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 983);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 984);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 985);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 986);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 987);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 988);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 989);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 990);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 991);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 992);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 993);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 994);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 995);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 996);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 997);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 998);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 999);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Stocks",
                keyColumn: "ProductInStockId",
                keyValue: 1000);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 10);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 11);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 12);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 13);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 14);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 15);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 16);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 17);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 18);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 19);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 20);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 21);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 22);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 23);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 24);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 25);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 26);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 27);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 28);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 29);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 30);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 31);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 32);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 33);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 34);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 35);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 36);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 37);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 38);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 39);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 40);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 41);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 42);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 43);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 44);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 45);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 46);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 47);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 48);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 49);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 50);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 51);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 52);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 53);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 54);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 55);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 56);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 57);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 58);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 59);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 60);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 61);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 62);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 63);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 64);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 65);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 66);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 67);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 68);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 69);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 70);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 71);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 72);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 73);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 74);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 75);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 76);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 77);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 78);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 79);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 80);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 81);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 82);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 83);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 84);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 85);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 86);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 87);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 88);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 89);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 90);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 91);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 92);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 93);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 94);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 95);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 96);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 97);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 98);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 99);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 100);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 101);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 102);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 103);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 104);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 105);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 106);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 107);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 108);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 109);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 110);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 111);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 112);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 113);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 114);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 115);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 116);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 117);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 118);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 119);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 120);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 121);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 122);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 123);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 124);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 125);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 126);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 127);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 128);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 129);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 130);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 131);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 132);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 133);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 134);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 135);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 136);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 137);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 138);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 139);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 140);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 141);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 142);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 143);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 144);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 145);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 146);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 147);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 148);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 149);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 150);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 151);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 152);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 153);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 154);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 155);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 156);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 157);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 158);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 159);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 160);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 161);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 162);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 163);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 164);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 165);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 166);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 167);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 168);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 169);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 170);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 171);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 172);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 173);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 174);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 175);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 176);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 177);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 178);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 179);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 180);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 181);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 182);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 183);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 184);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 185);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 186);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 187);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 188);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 189);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 190);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 191);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 192);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 193);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 194);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 195);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 196);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 197);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 198);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 199);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 200);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 201);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 202);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 203);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 204);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 205);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 206);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 207);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 208);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 209);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 210);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 211);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 212);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 213);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 214);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 215);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 216);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 217);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 218);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 219);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 220);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 221);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 222);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 223);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 224);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 225);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 226);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 227);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 228);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 229);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 230);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 231);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 232);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 233);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 234);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 235);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 236);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 237);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 238);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 239);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 240);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 241);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 242);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 243);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 244);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 245);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 246);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 247);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 248);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 249);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 250);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 251);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 252);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 253);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 254);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 255);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 256);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 257);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 258);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 259);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 260);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 261);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 262);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 263);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 264);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 265);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 266);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 267);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 268);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 269);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 270);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 271);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 272);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 273);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 274);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 275);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 276);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 277);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 278);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 279);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 280);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 281);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 282);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 283);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 284);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 285);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 286);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 287);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 288);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 289);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 290);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 291);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 292);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 293);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 294);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 295);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 296);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 297);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 298);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 299);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 300);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 301);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 302);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 303);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 304);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 305);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 306);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 307);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 308);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 309);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 310);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 311);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 312);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 313);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 314);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 315);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 316);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 317);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 318);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 319);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 320);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 321);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 322);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 323);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 324);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 325);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 326);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 327);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 328);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 329);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 330);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 331);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 332);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 333);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 334);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 335);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 336);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 337);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 338);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 339);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 340);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 341);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 342);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 343);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 344);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 345);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 346);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 347);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 348);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 349);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 350);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 351);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 352);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 353);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 354);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 355);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 356);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 357);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 358);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 359);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 360);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 361);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 362);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 363);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 364);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 365);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 366);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 367);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 368);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 369);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 370);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 371);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 372);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 373);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 374);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 375);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 376);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 377);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 378);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 379);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 380);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 381);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 382);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 383);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 384);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 385);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 386);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 387);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 388);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 389);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 390);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 391);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 392);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 393);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 394);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 395);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 396);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 397);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 398);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 399);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 400);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 401);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 402);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 403);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 404);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 405);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 406);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 407);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 408);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 409);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 410);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 411);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 412);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 413);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 414);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 415);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 416);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 417);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 418);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 419);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 420);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 421);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 422);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 423);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 424);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 425);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 426);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 427);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 428);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 429);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 430);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 431);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 432);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 433);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 434);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 435);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 436);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 437);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 438);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 439);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 440);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 441);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 442);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 443);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 444);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 445);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 446);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 447);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 448);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 449);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 450);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 451);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 452);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 453);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 454);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 455);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 456);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 457);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 458);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 459);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 460);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 461);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 462);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 463);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 464);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 465);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 466);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 467);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 468);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 469);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 470);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 471);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 472);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 473);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 474);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 475);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 476);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 477);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 478);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 479);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 480);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 481);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 482);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 483);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 484);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 485);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 486);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 487);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 488);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 489);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 490);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 491);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 492);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 493);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 494);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 495);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 496);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 497);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 498);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 499);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 500);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 501);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 502);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 503);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 504);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 505);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 506);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 507);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 508);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 509);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 510);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 511);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 512);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 513);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 514);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 515);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 516);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 517);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 518);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 519);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 520);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 521);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 522);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 523);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 524);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 525);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 526);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 527);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 528);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 529);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 530);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 531);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 532);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 533);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 534);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 535);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 536);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 537);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 538);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 539);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 540);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 541);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 542);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 543);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 544);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 545);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 546);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 547);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 548);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 549);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 550);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 551);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 552);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 553);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 554);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 555);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 556);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 557);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 558);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 559);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 560);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 561);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 562);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 563);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 564);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 565);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 566);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 567);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 568);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 569);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 570);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 571);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 572);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 573);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 574);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 575);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 576);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 577);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 578);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 579);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 580);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 581);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 582);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 583);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 584);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 585);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 586);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 587);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 588);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 589);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 590);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 591);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 592);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 593);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 594);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 595);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 596);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 597);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 598);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 599);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 600);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 601);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 602);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 603);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 604);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 605);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 606);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 607);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 608);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 609);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 610);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 611);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 612);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 613);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 614);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 615);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 616);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 617);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 618);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 619);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 620);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 621);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 622);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 623);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 624);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 625);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 626);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 627);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 628);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 629);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 630);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 631);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 632);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 633);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 634);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 635);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 636);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 637);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 638);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 639);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 640);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 641);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 642);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 643);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 644);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 645);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 646);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 647);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 648);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 649);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 650);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 651);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 652);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 653);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 654);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 655);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 656);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 657);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 658);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 659);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 660);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 661);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 662);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 663);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 664);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 665);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 666);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 667);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 668);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 669);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 670);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 671);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 672);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 673);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 674);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 675);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 676);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 677);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 678);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 679);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 680);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 681);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 682);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 683);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 684);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 685);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 686);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 687);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 688);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 689);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 690);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 691);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 692);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 693);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 694);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 695);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 696);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 697);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 698);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 699);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 700);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 701);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 702);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 703);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 704);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 705);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 706);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 707);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 708);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 709);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 710);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 711);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 712);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 713);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 714);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 715);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 716);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 717);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 718);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 719);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 720);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 721);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 722);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 723);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 724);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 725);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 726);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 727);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 728);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 729);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 730);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 731);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 732);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 733);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 734);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 735);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 736);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 737);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 738);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 739);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 740);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 741);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 742);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 743);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 744);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 745);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 746);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 747);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 748);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 749);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 750);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 751);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 752);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 753);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 754);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 755);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 756);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 757);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 758);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 759);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 760);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 761);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 762);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 763);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 764);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 765);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 766);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 767);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 768);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 769);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 770);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 771);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 772);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 773);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 774);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 775);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 776);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 777);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 778);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 779);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 780);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 781);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 782);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 783);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 784);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 785);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 786);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 787);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 788);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 789);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 790);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 791);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 792);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 793);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 794);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 795);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 796);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 797);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 798);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 799);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 800);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 801);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 802);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 803);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 804);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 805);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 806);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 807);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 808);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 809);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 810);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 811);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 812);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 813);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 814);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 815);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 816);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 817);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 818);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 819);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 820);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 821);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 822);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 823);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 824);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 825);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 826);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 827);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 828);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 829);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 830);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 831);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 832);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 833);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 834);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 835);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 836);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 837);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 838);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 839);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 840);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 841);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 842);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 843);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 844);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 845);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 846);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 847);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 848);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 849);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 850);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 851);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 852);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 853);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 854);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 855);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 856);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 857);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 858);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 859);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 860);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 861);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 862);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 863);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 864);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 865);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 866);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 867);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 868);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 869);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 870);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 871);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 872);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 873);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 874);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 875);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 876);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 877);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 878);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 879);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 880);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 881);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 882);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 883);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 884);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 885);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 886);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 887);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 888);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 889);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 890);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 891);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 892);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 893);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 894);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 895);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 896);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 897);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 898);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 899);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 900);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 901);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 902);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 903);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 904);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 905);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 906);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 907);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 908);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 909);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 910);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 911);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 912);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 913);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 914);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 915);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 916);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 917);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 918);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 919);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 920);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 921);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 922);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 923);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 924);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 925);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 926);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 927);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 928);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 929);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 930);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 931);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 932);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 933);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 934);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 935);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 936);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 937);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 938);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 939);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 940);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 941);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 942);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 943);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 944);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 945);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 946);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 947);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 948);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 949);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 950);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 951);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 952);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 953);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 954);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 955);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 956);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 957);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 958);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 959);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 960);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 961);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 962);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 963);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 964);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 965);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 966);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 967);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 968);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 969);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 970);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 971);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 972);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 973);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 974);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 975);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 976);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 977);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 978);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 979);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 980);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 981);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 982);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 983);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 984);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 985);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 986);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 987);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 988);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 989);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 990);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 991);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 992);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 993);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 994);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 995);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 996);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 997);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 998);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 999);

            migrationBuilder.DeleteData(
                schema: "Catalog",
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1000);
        }
    }
}
