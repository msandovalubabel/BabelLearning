﻿using Catalog.Persistence.Database;
using Catalog.Service.Queries.DTO;
using Microsoft.EntityFrameworkCore;
using Service.Common.Collection;
using Service.Common.Mapping;
using Service.Common.Paging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catalog.Service.Queries
{
    public class ProductQueryService:IProductQueryService
    {
        private readonly ApplicationDbContext _contex;

        public ProductQueryService(ApplicationDbContext context)
        {
            _contex = context;
        }

        public async Task<DataCollection<ProductDto>> GetAllAsync(int page, int take, IEnumerable<int> products = null)
        {
            var callection = await _contex.Products.Where(
                x => products == null || products.Contains(x.ProductId)).OrderByDescending(x => x.ProductId)
                .GetPagedAsync(page, take);

            return callection.MapTo<DataCollection<ProductDto>>();
        }

        public async Task<ProductDto> GetAsync(int id)
        {
            return (await _contex.Products.SingleAsync(x=>x.ProductId==id)).MapTo<ProductDto>();
        }
    }
}
