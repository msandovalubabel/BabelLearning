﻿using Api.Gateway.WebClient.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Gateway.WebClient.RemoteInterface
{
    public interface IAutorRemote
    {
        Task<(bool resultado, AutorDto autor, string ErrorMessage)> GetAutor(string Id);
    }
}
