﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Libreria.Domain
{
    [BsonCollection("Libro")]
    public class LibroEntity:Document
    {
        [BsonElement("titulo")]
        public string Titulo { get; set; }
        [BsonElement("descripcion")]
        public string Descripcion { get; set; }

        [BsonElement("precio")]
        public int Precio { get; set; }

        [BsonElement("fechapublicacion")]
        public DateTime? FechaPublicacion { get; set; }

        [BsonElement("autor")]
        public AutorEntity Auto { get; set; }
    }
}
