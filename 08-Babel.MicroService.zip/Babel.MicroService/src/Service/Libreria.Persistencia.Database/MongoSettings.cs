﻿using System;

namespace Libreria.Persistencia.Database
{
    public class MongoSettings
    {
        public string ConnectionString { get; set; }
        public string Database { get; set; }
    }
}
