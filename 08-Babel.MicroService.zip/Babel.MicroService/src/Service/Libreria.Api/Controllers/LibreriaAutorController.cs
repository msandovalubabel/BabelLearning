﻿using Libreria.Domain;
using Libreria.Persistencia.Database;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Libreria.Api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class LibreriaAutorController : ControllerBase
    {
        private readonly IMongoRepository<AutorEntity> _autorRepository;

        public LibreriaAutorController(IMongoRepository<AutorEntity> autorRepository)
        {
            _autorRepository = autorRepository;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AutorEntity>>> Get()
        {
            var autores = await _autorRepository.GetAll();
            return Ok(autores);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AutorEntity>> GetById(string id)
        {
            var autor = await _autorRepository.GetById(id);
            return Ok(autor);
        }

        [HttpPut("{id}")]
        public async Task Put(string id, AutorEntity autor)
        {
            autor.Id = id;
            await _autorRepository.UpdateDocument(autor);
        }
        [HttpDelete("{id}")]
        public async Task Delete(string id)
        {
            await _autorRepository.DeleteById(id);
        }
    }
}
