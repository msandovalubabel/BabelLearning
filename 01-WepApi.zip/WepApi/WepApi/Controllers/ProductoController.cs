﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WepApi.Controllers
{
    [ApiController]
    [Route("productos")]
    public class ProductoController:ControllerBase
    {

        [HttpGet]
        public ActionResult<List<Producto>> GetAll()
        {
            return articulos;
        }

        [HttpGet("{id}")]
        public ActionResult<Producto> Get(int id)
        {
            return articulos.Single(r=>r.Id==id);
        }
        [HttpPost]
        public ActionResult Create(Producto producto)
        {
            producto.Id = articulos.Count() + 1;
            articulos.Add(producto);
            return CreatedAtAction("Get",new {id=producto.Id },producto);
        }
        [HttpPut("{productId}")]
        public ActionResult Update(int productid,Producto producto)
        {
            var original = articulos.Single(x => x.Id == productid);
            original.Nombre = producto.Nombre;
            original.Precio = producto.Precio;
            original.Descripcion = producto.Descripcion;
            return NoContent();
        }

        [HttpDelete("{productId}")]
        public ActionResult Delete(int productid)
        {
            articulos = articulos.Where(x => x.Id != productid).ToList();
            return NoContent();
        }

        private static List<Producto> articulos = new List<Producto>
        {
            new Producto{
            Id=1,
            Nombre="Mouse",
            Precio=3500,
            Descripcion="USB 3 botones"
            },
            new Producto{
                Id=2,
                Nombre="Teclado",
                Precio=3500,
                Descripcion="USB Español"
            }
        };
    }
}
